/*
 * Author: Minho Kim (mhkim@ramo.yonsei.ac.kr)
 * Yonsei Univ. in Seoul, South-Korea.
 * This is to simulate and analysis for wireless-TCP
 * TCP + LTE + mmwave + mobility + earlyAck(considering RLC buffer status)
 * modification for window update procedure in a base station. 6/24/2016
 */









#include "ns3/point-to-point-module.h"
#include "ns3/mmwave-helper.h"
#include "ns3/epc-helper.h"
#include "ns3/mmwave-point-to-point-epc-helper.h"
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/ipv4-global-routing-helper.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/applications-module.h"
#include "ns3/point-to-point-helper.h"
#include "ns3/config-store.h"

#include "ns3/epc-gtpu-header.h"
#include "ns3/tcp-option-winscale.h"
//#include <algorithm>;
#include "ns3/building.h"
#include <ns3/buildings-helper.h>
#include <ns3/buildings-module.h>
#include <ns3/constant-position-mobility-model.h>
#include <ns3/mobility-building-info.h>
#include "ns3/internet-trace-helper.h"
#include "ns3/lte-rlc.h"
#include "ns3/lte-rlc-um.h"
#include "ns3/lte-ue-rrc.h"
#include <ns3/lte-radio-bearer-info.h>
#include <stdio.h>
#include <ns3/log.h>
#include <ns3/building-list.h>
#include <ns3/angles.h>
#include <map>
#include "ns3/packet-metadata.h"
//#include "buffer.h"
//#include "object.h"
//#include "ptr.h"
//#include "attribute.h"
//#include <ns3/object-ptr-container.h>


/*
 *
 *     Server ----------[PGW]---------------[eNB]---------------UE
 *     1.0.0.1       1.0.0.2                                           7.0.0.2
 *
 *
 *
 * */


using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("mhtcp11");



typedef std::map<SequenceNumber32, Ptr<Packet> >::const_iterator Iterator;

 /*MyTcp application on server*/

class MyTcp : public Application
{
public:
	MyTcp();
	virtual ~MyTcp();

	void Setup (Ptr<Socket> socket, Address address, uint32_t packetSize, uint32_t nPackets, DataRate dataRate);

private:
	virtual void StartApplication(void);
	virtual void StopApplication(void);
	void ScheduledTx(void);
	void SendPacket(void);

	Ptr<Socket> m_socket;
	Address m_peer;
	uint32_t m_packetSize;
	uint32_t m_nPackets;
	DataRate m_dataRate;
	EventId m_sendEvent;
	bool m_running;
	uint32_t m_packetsSent;

};

MyTcp::MyTcp()
	: m_socket(0),
	  m_peer(),
	  m_packetSize(0),
	  m_nPackets(0),
	  m_dataRate(0),
	  m_sendEvent(),
	  m_running(false),
	  m_packetsSent(0)
{

}

MyTcp::~MyTcp()
{
	m_socket=0;
}

void MyTcp::Setup(Ptr<Socket> socket, Address address, uint32_t packetSize, uint32_t nPackets, DataRate dataRate)
{
	m_socket = socket;
	m_peer = address;
	m_packetSize = packetSize;
	m_nPackets = nPackets;
	m_dataRate = dataRate;
}


void MyTcp::StartApplication(void)
{
	m_running = true;
	m_packetsSent = 0;
	m_socket->Bind();
	m_socket->Connect(m_peer);
	SendPacket();
}

void MyTcp::StopApplication(void)
{
	m_running = false;

	if(m_sendEvent.IsRunning())
	{
		Simulator::Cancel(m_sendEvent);
	}

	if(m_socket)
	{
		m_socket->Close();
	}
}

void MyTcp::ScheduledTx(void)
{
	if( m_running)
	{
		Time tNext( Seconds(m_packetSize * 8 / static_cast<double> (m_dataRate.GetBitRate() ) ));
		m_sendEvent = Simulator::Schedule( tNext , &MyTcp::SendPacket , this );
	}

}

void MyTcp::SendPacket(void)
{

	static int send_num = 0;
	Ptr<Packet> packet = Create<Packet> (m_packetSize);
	m_socket->Send (packet);
	NS_LOG_DEBUG ("Sending:    "<<send_num++ << "\t" << Simulator::Now ().GetSeconds ());
//	std::cout << "Sending:    " <<++send_num << "\t" << Simulator::Now ().GetSeconds ()<<std::endl;

  	if (++m_packetsSent < m_nPackets)
	{
	    ScheduledTx ();
	}
}

/************* start.. Buffer Class for Local Retransmission **********************/

class AlayerBuffer : public AttributeValue
{
public:



  /** Default constructor. */
  AlayerBuffer (uint32_t max);
//  AlayerBuffer ();

  Iterator Begin (void) const;

  Iterator End (void) const;

  uint32_t GetN (void) const;

  uint16_t GetLen (SequenceNumber32 seq) const;

  Ptr<Packet> GetPacket(SequenceNumber32 seq);

  Iterator FindCloseTo (SequenceNumber32 seq) ;

  void Insert (SequenceNumber32 seq, Ptr<Packet> pkt);

  void Swap (SequenceNumber32 seq, Ptr<Packet> pkt);

  void Delete (bool isFromFirst, SequenceNumber32 seq);

  void Delete (Iterator it);

  void Retransmission (SequenceNumber32 seq);

  virtual Ptr<AttributeValue> Copy (void) const;

  virtual std::string SerializeToString (Ptr<const AttributeChecker> checker) const;

  virtual bool DeserializeFromString (std::string value, Ptr<const AttributeChecker> checker);


  std::map<SequenceNumber32, Ptr<Packet> > m_buffer;

  uint32_t maxBufferSize;
};

/************* end.. Buffer Class for Local Retransmission **********************/

/************* start.. Alayer buffer implementation **********************/

AlayerBuffer::AlayerBuffer(uint32_t max)
{
	maxBufferSize = max;
}

//AlayerBuffer::AlayerBuffer()
//{
////do nothing
//}

Iterator AlayerBuffer::Begin (void) const
{
	return m_buffer.begin();
}

Iterator AlayerBuffer::End(void) const
{
	return m_buffer.end();
}

uint32_t AlayerBuffer::GetN (void) const
{
	return m_buffer.size();
}


uint16_t AlayerBuffer::GetLen(SequenceNumber32 seq) const
{
	Iterator it = m_buffer.find(seq);
	Ptr<Packet> pkt;
	uint16_t len = 0;
	if ( it != m_buffer.end() )
	{
		pkt = m_buffer.find(seq)->second;

	}
	else
	{
		if(seq == m_buffer.end()->first)
		{
			pkt = m_buffer.end()->second;
		}
		else
		{
			return 0;
		}

	}
	len =  pkt->GetSize()-92; //headers ;
//	len =  pkt->GetSerializedSize() - 32; //tcp header ;

//	std::cout << " getserialized() size : " << pkt->GetSerializedSize() << std::endl;
//	std::cout << " getsize() size : " << pkt->GetSize() << std::endl;

	return len;

}

Ptr<Packet> AlayerBuffer::GetPacket(SequenceNumber32 seq)
{
	Iterator it = m_buffer.find(seq);
	Ptr<Packet> pkt ;
	if ( it != m_buffer.end() )
	{
		pkt = m_buffer.find(seq)->second;

	}
	return pkt->Copy();
}



Iterator AlayerBuffer::FindCloseTo (SequenceNumber32 seq)
{
	Iterator it ;
	for ( it = m_buffer.begin() ; it!= m_buffer.end() ; it++)
	{
		if(it->first == seq)
		{
			return (it);
		}
		if(it->first >= seq)
		{
			return (it);
		}
	}
	return it;
}

void AlayerBuffer::Delete (bool isFromFirst, SequenceNumber32 seq)
{

	std::cout << "deleting...." << std::endl;
//	std::cout << "the sequence number is " << seq << std::endl;

	Iterator it = m_buffer.find(seq);

	if( isFromFirst )
	{
		if(it == m_buffer.end() )
		{

			std::cout << "It is deleting from first" << std::endl;
			std::cout << "No data for specific Ack info in Alayerbuffer... for consecutive packets" << std::endl;
//			it = FindCloseTo(seq);
//			Delete(it);

//			std::cout << "And,, it isn't the largest sequence number is the seq.." << std::endl;

//			std::cout << "The largest seqeunce number is.. " <<m_buffer.rbegin()->first << std::endl;
		}
		else
		{
			Delete(it);
		}
//		m_buffer.find();


		return;

	}else
	{
		std::cout << "It is deleting for one packet" << std::endl;

		if(it == m_buffer.end() )
		{


			std::cout << "No data for specific Ack info in Alayerbuffer... for a single packet" << std::endl;
//			it = FindCloseTo(seq);
//			m_buffer.erase( it._M_const_cast()  );

//			std::cout << "And,, it isn't the largest sequence number is the seq.." << std::endl;


		}
		else
		{

			m_buffer.erase( it._M_const_cast()  );
		}




		return;

	}


}

void AlayerBuffer::Delete (Iterator it)
{
//	m_buffer.erase( m_buffer.begin(), it._M_const_cast() );
	m_buffer.erase( m_buffer.begin(), it._M_const_cast() );
	return;
}


void AlayerBuffer::Retransmission (SequenceNumber32 seq)
{

}

void AlayerBuffer::Insert(SequenceNumber32 seq, Ptr<Packet> pkt)
{


	if(m_buffer.size() >= maxBufferSize )
	{
		std::cout << "Buffer Over Flow!!!! at A Layer" << Simulator::Now() <<std::endl;
		return;
	}
	m_buffer.insert( std::pair<SequenceNumber32, Ptr<Packet> > (seq, pkt) );


	return;
}

void AlayerBuffer::Swap (SequenceNumber32 seq, Ptr<Packet> pkt)
{

	Iterator it = m_buffer.find(seq);
	if(it != m_buffer.end() )
	{


	}
}

Ptr<AttributeValue> AlayerBuffer::Copy (void) const
{
	return Create<AlayerBuffer>(*this);
}

std::string AlayerBuffer::SerializeToString (Ptr<const AttributeChecker> checker) const
{
  NS_LOG_FUNCTION (this << checker);
  std::ostringstream oss;
  Iterator it;
  for (it = Begin (); it != End (); ++it)
    {
      oss << (*it).second;
      if (it != End ())
        {
          oss << " ";
        }
    }
  return oss.str ();
}
bool AlayerBuffer::DeserializeFromString (std::string value, Ptr<const AttributeChecker> checker)
{
  NS_LOG_FUNCTION (this << value << checker);
  NS_FATAL_ERROR ("cannot deserialize a set of object pointers.");
  return true;
}


static Ptr<Node> enb_node;
static Ptr<Node> ue_node;
static Ptr<Packet> sample_datapacket;


/*Simulation parameters*/

static const uint32_t  rlcMax_ThreshBuf =3000000;
static const uint32_t  sndBufSize = 131072*100;
static const uint32_t  rcvBufSize = 131082*100;
static const uint32_t  distance = 210; // meters, between a bs and mobile
static const TimeValue  zeroWinProbeTime = Seconds(0.2);
static const double  target_bufRatio = 1;
static const bool enableEA = true;
static const uint16_t  howmany_retrans = 40;  // how many consequence packets are retransmitted..
FILE* log_file;
char fname[255];
double simTime = 15 ;
std::string tcpProtocol = "TcpNewReno";

std::string bandwidthInet = "100Gb/s";
std::string bandwidthBsUe = "100Gb/s";
int mtu = 1500;


uint32_t packetSize = 1400;
uint32_t segmentSize = 1400;
uint32_t nPackets = 2000000;
uint32_t currentRlcBuf = 50000;
uint16_t windowFactor = 256;
std::string dataRate = "100Mbps";
std::string delay = "20ms";
std::string delayBsUe = "20ms";
int basicQueueSize = 20000; // num of packets in queue

Ptr<AlayerBuffer> aLayerBuffer = Create<AlayerBuffer>(6000000); // to make this global variable

Vector enbPosition = Vector(30,distance,20);
Vector ueStarting = Vector(0,0,1.5);
Vector ueVelocity = Vector(2,0,0);


///*Simulation parameters*/
//static const uint32_t  rlcMax_ThreshBuf =3000000;
//static const uint32_t  sndBufSize = 131072*100;
//static const uint32_t  rcvBufSize = 131072*100;
//static const uint32_t  distance = 210; // meters, between a bs and mobile
//static const TimeValue  zeroWinProbeTime = Seconds(0.2);
//static const double  target_bufRatio = 1;
//static const bool enableEA = true;
//static const uint16_t  howmany_retrans = 40;  // how many consequence packets are retransmitted..
//FILE* log_file;
//char fname[255];
//double simTime = 15 ;
//std::string tcpProtocol = "TcpNewReno";
//
//std::string bandwidthInet = "100Gb/s";
//std::string bandwidthBsUe = "100Gb/s";
//int mtu = 1500;
//
//
//uint32_t packetSize = 1400;
//uint32_t segmentSize = 1400;
//uint32_t nPackets = 2000000;
//uint32_t currentRlcBuf = 50000;
//uint16_t windowFactor = 256;
//std::string dataRate = "100Mbps";
//std::string delay = "20ms";
//std::string delayBsUe = "20ms";
//int basicQueueSize = 20000; // num of packets in queue
//
//Ptr<AlayerBuffer> aLayerBuffer = Create<AlayerBuffer>(6000000); // to make this global variable
//
//Vector enbPosition = Vector(30,distance,20);
//Vector ueStarting = Vector(0,0,1.5);
//Vector ueVelocity = Vector(2,0,0);



/************* end.. Alayer buffer implementation **********************/






















Ptr<LteRlcUm> GetDrbRlc(Ptr<Node> enb, Ptr<Node> ue)
{

	Ptr<MmWaveEnbNetDevice> mmWaveEnbNetDevice = enb->GetDevice(0)->GetObject<MmWaveEnbNetDevice>();
	Ptr<LteEnbRrc> lteEnbRrc = mmWaveEnbNetDevice->GetRrc();


	Ptr<MmWaveUeNetDevice> mmWaveUeNetDevice = ue->GetDevice(0)->GetObject<MmWaveUeNetDevice>();
	uint16_t ueRnti = mmWaveUeNetDevice->GetRrc()->GetRnti();
	Ptr<UeManager> ueManager = lteEnbRrc->GetUeManager(ueRnti);

	ObjectPtrContainerValue tmpPtrCont;
	ueManager->GetAttribute("DataRadioBearerMap",tmpPtrCont);
	Ptr<Object> tmpObject = tmpPtrCont.Get(1);
	Ptr<LteDataRadioBearerInfo> dataRadioBearer = tmpObject->GetObject<LteDataRadioBearerInfo>();
	Ptr<MmWaveEnbNetDevice> ueTargetEnb = mmWaveUeNetDevice->GetTargetEnb();

	PointerValue tmpPtr;
	dataRadioBearer->GetAttribute("LteRlc",tmpPtr);
	tmpObject = tmpPtr.GetObject();
	Ptr<LteRlcUm> lteRlc = tmpObject->GetObject<LteRlcUm>();



	return lteRlc;
}


bool IsLos (Ptr<NetDevice> ueDevice, Ptr<NetDevice> enbDevice)
{


	Ptr<MobilityModel> ue_mm = ueDevice->GetNode()->GetObject<MobilityModel>();
	Ptr<MobilityModel> enb_mm = enbDevice->GetNode()->GetObject<MobilityModel>();

//	Ptr<MobilityBuildingInfo> ue_mbi = ue_mm->GetObject<MobilityBuildingInfo>();
//	Ptr<MobilityBuildingInfo> enb_mbi = enb_mm->GetObject<MobilityBuildingInfo>();

	bool los = true;
	for (BuildingList::Iterator bit = BuildingList::Begin (); bit != BuildingList::End (); ++bit)
	{
		Box boundaries = (*bit)->GetBoundaries ();
		Vector locationA = ue_mm->GetPosition ();
		Vector locationB = enb_mm->GetPosition ();
		Angles pathAngles (locationB, locationA);
		double angle = pathAngles.phi;
		if (angle >= M_PI/2 || angle < -M_PI/2)
		{
			locationA = enb_mm->GetPosition ();
			locationB = ue_mm->GetPosition ();
			Angles pathAngles (locationB, locationA);
			angle = pathAngles.phi;
		}

		if (angle >=0 && angle < M_PI/2 )
		{
			Vector loc1(boundaries.xMax,boundaries.yMin,boundaries.zMin);
			Vector loc2(boundaries.xMin,boundaries.yMax,boundaries.zMin);
			Angles angles1 (loc1,locationA);
			Angles angles2 (loc2,locationA);
			if (angle > angles1.phi && angle < angles2.phi && locationB.x > boundaries.xMin && locationB.y > boundaries.yMin)
			{
				los = false;
				break;
			}
		}
		else if (angle >= -M_PI/2 && angle < 0)
		{
			Vector loc1(boundaries.xMin,boundaries.yMin,boundaries.zMin);
			Vector loc2(boundaries.xMax,boundaries.yMax,boundaries.zMin);
			Angles angles1 (loc1,locationA);
			Angles angles2 (loc2,locationA);
			if (angle > angles1.phi && angle < angles2.phi && locationB.x > boundaries.xMin && locationB.y < boundaries.yMax)
			{
				los = false;
				break;
			}
		}
	}

	return los;

}




static void CwndChange (Ptr<OutputStreamWrapper> stream, uint32_t oldCwnd, uint32_t newCwnd )
{
	*stream->GetStream() << Simulator::Now().GetSeconds() << "\t" << oldCwnd << "\t" << newCwnd << std::endl ;
}





void SendEarlyAck1( uint16_t ipLen, Ptr<Packet> dataPacket, Ptr<Ipv4> ipv4, uint32_t interface
			,uint16_t preAckWin , Ipv4Header preIpv4Header, TcpHeader preTcpHeader, uint8_t preTcpFlag,
			Ipv4Header gtpIpv4Header, GtpuHeader gtpHeader, UdpHeader gtpUdpHeader)
{



//	std::cout << "Early Ack has been generated" << std::endl;

	Ipv4Header ipv4HeaderEA; // Early Ack header corresponding to received data
	ipv4HeaderEA = preIpv4Header;
	ipv4HeaderEA.SetDscp( Ipv4Header::DSCP_AF13 );
	unsigned int tempWindow = 0;


	static SequenceNumber32 earlyAckedSeq(0);



	uint16_t tcpTotalSize = ipLen;

//	ipv4->GetNetDevice(2)->get


	gtpIpv4Header.EnableChecksum();

	Ptr<Ipv4Route> ipv4RouteEA = Create<Ipv4Route>();
	ipv4RouteEA->SetDestination( gtpIpv4Header.GetDestination() );
	ipv4RouteEA->SetGateway( gtpIpv4Header.GetDestination() );
	ipv4RouteEA->SetOutputDevice( ipv4->GetNetDevice(interface)); // send back to the interface where it comes from
	ipv4RouteEA->SetSource( gtpIpv4Header.GetSource() );


	TcpHeader originTcpHeader;
	TcpHeader tcpHeaderEA;

	dataPacket->PeekHeader(originTcpHeader);
	tcpHeaderEA = preTcpHeader;


	SequenceNumber32 dataSeqNum = originTcpHeader.GetSequenceNumber();
	uint32_t tcpHeaderSize = originTcpHeader.GetLength()*4;
	uint16_t tcpdatasize = tcpTotalSize - tcpHeaderSize; //for calculate ack num for data

//	std::cout << "tcpTotalSize :" << tcpTotalSize << std::endl;
//	std::cout << "tcpHeaderSize :" << tcpHeaderSize << std::endl;
//	std::cout << "dataSeqNum :" << dataSeqNum << std::endl;

	tcpHeaderEA.SetAckNumber(dataSeqNum + tcpdatasize);
	tempWindow = (unsigned int)((rlcMax_ThreshBuf-currentRlcBuf)/windowFactor < preAckWin) ? (rlcMax_ThreshBuf-currentRlcBuf)/windowFactor : preAckWin;
	if ( tempWindow*windowFactor < 1400 )
	{
	 	tempWindow = 0;
	}
	tcpHeaderEA.SetWindowSize( tempWindow );
//	tcpHeaderEA.SetFlags( 512 );

//	tcpHeaderEA.SetFlags(tcpHeaderEA.GetFlags() + 32 );
	tcpHeaderEA.EnableChecksums();


	dataPacket->RemoveHeader(originTcpHeader);
	Ptr<Packet> newpacket = Create<Packet>(0);
	newpacket->AddHeader(tcpHeaderEA);
	newpacket->AddHeader(ipv4HeaderEA);
	newpacket->AddHeader(gtpHeader);
	newpacket->AddHeader(gtpUdpHeader);


	ipv4->SendWithHeader(newpacket, gtpIpv4Header, ipv4RouteEA);
	earlyAckedSeq = tcpHeaderEA.GetAckNumber();


}


void SendWinUpdate( Ptr<Packet> dataPacket, Ptr<Ipv4> ipv4, uint32_t interface
			,Ipv4Header ipv4Header, TcpHeader tcpHeader, Ipv4Header gtpIpv4Header
			,GtpuHeader gtpHeader, UdpHeader gtpUdpHeader, SequenceNumber32 lastAck)
{

//	Ipv4Header ipv4Header;
//	dataPacket->PeekHeader(ipv4Header);
//	dataPacket->RemoveHeader(ipv4Header);
//	ipv4Header.SetDscp( Ipv4Header::DSCP_AF23 );

	//	TcpHeader tcpHeader;
	//	dataPacket->PeekHeader(tcpHeader);
	//	dataPacket->RemoveHeader(tcpHeader);


	std::cout << " SEND WINDOW UPDATE PROCEDURE!!!!!!!!!!!!!!!!!!!"  << std::endl;
	std::cout << "                                                "  << std::endl;
	std::cout << "                                                "  << std::endl;
	std::cout << "                                                "  << std::endl;
	std::cout << "                                                "  << std::endl;
	std::cout << "                                                "  << std::endl;


	gtpIpv4Header.EnableChecksum();
	ipv4Header.SetDscp( Ipv4Header::DSCP_AF23 );

	dataPacket->RemoveHeader(tcpHeader);

	tcpHeader.SetAckNumber(lastAck);
//	tcpHeader.SetWindowSize( (unsigned int)(rlcMax_ThreshBuf-currentRlcBuf)/windowFactor);
	tcpHeader.SetWindowSize(  (unsigned int)rcvBufSize /windowFactor);

	Ptr<Ipv4Route> ipv4Route = Create<Ipv4Route>();
	ipv4Route->SetDestination( gtpIpv4Header.GetDestination() );
	ipv4Route->SetGateway( gtpIpv4Header.GetDestination() );
	ipv4Route->SetOutputDevice( ipv4->GetNetDevice(interface)); // send back to the interface where it comes from
	ipv4Route->SetSource( gtpIpv4Header.GetSource() );

	dataPacket->AddHeader(tcpHeader);
	dataPacket->AddHeader(ipv4Header);
	dataPacket->AddHeader(gtpHeader);
	dataPacket->AddHeader(gtpUdpHeader);


	ipv4->SendWithHeader(dataPacket, gtpIpv4Header, ipv4Route);

}




void SendRetransmission( uint16_t tcpLen, SequenceNumber32 targetSeq,  Ptr<Ipv4> ipv4, uint32_t interface
			,Ipv4Header preIpv4Header, TcpHeader preTcpHeader
			,Ipv4Header preGtpIpv4Header, UdpHeader preGtpUdpHeader, GtpuHeader preGtpHeader)
{



	Ptr<Ipv4Route> ipv4RouteRetrans = Create<Ipv4Route>();
	ipv4RouteRetrans->SetDestination( preIpv4Header.GetSource() );
	ipv4RouteRetrans->SetGateway( preIpv4Header.GetSource() );
	ipv4RouteRetrans->SetOutputDevice( ipv4->GetNetDevice(interface)); // send back to the interface where it comes from
	ipv4RouteRetrans->SetSource( preIpv4Header.GetDestination() );


	TcpHeader tcpHeaderRetrans;
	tcpHeaderRetrans = preTcpHeader;
	tcpHeaderRetrans.SetSourcePort( preTcpHeader.GetDestinationPort());
	tcpHeaderRetrans.SetDestinationPort( preTcpHeader.GetSourcePort());
	tcpHeaderRetrans.SetSequenceNumber( targetSeq );
	tcpHeaderRetrans.SetAckNumber( SequenceNumber32(1));
	tcpHeaderRetrans.SetWindowSize(rcvBufSize/windowFactor);
	tcpHeaderRetrans.EnableChecksums();



	Ipv4Header ipv4HeaderRetrans; // Retransmission packet header corresponding to received data
	ipv4HeaderRetrans = preIpv4Header;
	ipv4HeaderRetrans.SetDscp( Ipv4Header::DSCP_AF33 );
	ipv4HeaderRetrans.SetPayloadSize(tcpLen + tcpHeaderRetrans.GetLength()*4 );
	ipv4HeaderRetrans.SetSource(preIpv4Header.GetDestination());
	ipv4HeaderRetrans.SetDestination(preIpv4Header.GetSource());

	GtpuHeader gtpHeader = preGtpHeader;
	gtpHeader.SetLength(4+20+ipv4HeaderRetrans.GetPayloadSize());

	UdpHeader gtpUdpHeader = preGtpUdpHeader;
	gtpUdpHeader.ForcePayloadSize(gtpHeader.GetLength() + 8 + 8);


	Ipv4Header gtpIpv4Header = preGtpIpv4Header;
	gtpIpv4Header.SetDestination( preGtpIpv4Header.GetSource());
	gtpIpv4Header.SetSource( preGtpIpv4Header.GetDestination());
	gtpIpv4Header.SetPayloadSize( gtpHeader.GetLength() + 8 + 8);


//	ipv4HeaderRetrans.Print( std::cout);
//	std::cout << "" <<std::endl;


//	Ptr<Packet> newpacket = Create<Packet>(tcpLen);
	Ptr<Packet> newpacket = Create<Packet>(1400);

	newpacket->AddHeader(tcpHeaderRetrans);
	newpacket->AddHeader(ipv4HeaderRetrans);
	newpacket->AddHeader(gtpHeader);
	newpacket->AddHeader(gtpUdpHeader);





	std::cout << " do retransmission!!!@@@@@" << Simulator::Now()<<std::endl;


	ipv4->SendWithHeader(newpacket, gtpIpv4Header, ipv4RouteRetrans);

	std::cout << " @@@@@@retransmission!!!  complete!" << Simulator::Now()<<std::endl;

}

void SendRetransmission1(SequenceNumber32 targetSeq,  Ptr<Ipv4> ipv4, uint32_t interface)
{




	Ptr<Ipv4Route> ipv4RouteRetrans = Create<Ipv4Route>();
	ipv4RouteRetrans->SetDestination( Ipv4Address("7.0.0.2") );
//	ipv4RouteRetrans->SetGateway( Ipv4Address("7.0.0.2") );
	ipv4RouteRetrans->SetOutputDevice( ipv4->GetNetDevice(interface));
	ipv4RouteRetrans->SetSource( Ipv4Address("1.0.0.1") );




	uint16_t howmanyRetrans = (howmany_retrans < aLayerBuffer->GetN())? howmany_retrans:aLayerBuffer->GetN();

	for (uint16_t index = 0 ; index < howmanyRetrans; index++)
	{
		Ptr<Packet> newpacket1= sample_datapacket->Copy();
		Ptr<Packet> newpacket2= Create<Packet>(  aLayerBuffer->GetLen(targetSeq) );



		Ipv4Header gtpIpv4Header;
		newpacket1->PeekHeader(gtpIpv4Header);
		newpacket1->RemoveHeader(gtpIpv4Header);

		UdpHeader gtpUdpHeader;
		newpacket1->PeekHeader(gtpUdpHeader);
		newpacket1->RemoveHeader(gtpUdpHeader);

		GtpuHeader gtpHeader;
		newpacket1->PeekHeader(gtpHeader);
		newpacket1->RemoveHeader(gtpHeader);

		gtpUdpHeader.ForcePayloadSize(gtpHeader.GetLength() + 8 + 8);

		Ipv4Header ipv4Header;
		newpacket1->PeekHeader(ipv4Header);
		newpacket1->RemoveHeader(ipv4Header);
		ipv4Header.SetDscp(Ipv4Header::DSCP_AF33);

		std::cout << " do retransmission!!!@@@@@" << Simulator::Now()<<std::endl;

		TcpHeader tcpHeader;
		newpacket1->PeekHeader(tcpHeader);
		newpacket1->RemoveHeader(tcpHeader);
		tcpHeader.SetSequenceNumber(targetSeq);
		tcpHeader.SetWindowSize(rcvBufSize/windowFactor);
	//
	//	tcpHeader.EnableChecksums();

		newpacket2->AddHeader(tcpHeader);
		newpacket2->AddHeader(ipv4Header);
		newpacket2->AddHeader(gtpHeader);
		newpacket2->AddHeader(gtpUdpHeader);
	//	newpacket->AddPaddingAtEnd(1400);

		std::cout << "Retransmission index :" << index << "target seq: " << targetSeq << std::endl;
		ipv4->SendWithHeader(newpacket2, gtpIpv4Header, ipv4RouteRetrans);

		targetSeq += aLayerBuffer->GetLen(targetSeq);

	}

	std::cout << " @@@@@@retransmission!!!  complete!" << Simulator::Now()<<std::endl;
}

void SendRetransmission2(SequenceNumber32 targetSeq,  Ptr<Ipv4> ipv4, uint32_t interface)
{





	Ptr<Ipv4Route> ipv4RouteRetrans = Create<Ipv4Route>();
	ipv4RouteRetrans->SetDestination( Ipv4Address("10.0.0.5") );
	ipv4RouteRetrans->SetGateway( Ipv4Address("10.0.0.5") );
	ipv4RouteRetrans->SetOutputDevice( ipv4->GetNetDevice(interface));
	ipv4RouteRetrans->SetSource( Ipv4Address("10.0.0.6") );


	Ptr<Packet> newpacket = sample_datapacket->Copy();
//
//
//	Ipv4Header gtpIpv4Header;
//	newpacket->PeekHeader(gtpIpv4Header);
//	newpacket->RemoveHeader(gtpIpv4Header);
//
//	UdpHeader gtpUdpHeader;
//	newpacket->PeekHeader(gtpUdpHeader);
//	newpacket->RemoveHeader(gtpUdpHeader);
//
//	GtpuHeader gtpHeader;
//	newpacket->PeekHeader(gtpHeader);
//	newpacket->RemoveHeader(gtpHeader);
//
//	Ipv4Header ipv4Header;
//	newpacket->PeekHeader(ipv4Header);
//	newpacket->RemoveHeader(ipv4Header);

	TcpHeader tcpHeader;
	newpacket->PeekHeader(tcpHeader);
//	newpacket->RemoveHeader(tcpHeader);
	tcpHeader.SetSequenceNumber(targetSeq);
	tcpHeader.EnableChecksums();


//	newpacket->AddHeader(tcpHeader);
//	newpacket->AddHeader(ipv4Header);
//	newpacket->AddHeader(gtpHeader);
//	newpacket->AddHeader(gtpUdpHeader);


	std::cout << " do retransmission!!!@@@@@" << Simulator::Now()<<std::endl;

//	ipv4->SendWithHeader(newpacket, gtpIpv4Header, ipv4RouteRetrans);
	ipv4->Send(newpacket , Ipv4Address("1.0.0.1") , Ipv4Address("7.0.0.2") , 6 , ipv4RouteRetrans);


	std::cout << " @@@@@@retransmission!!!  complete!" << Simulator::Now()<<std::endl;

}

void SendRetransmission3(SequenceNumber32 targetSeq,  Ptr<Ipv4> ipv4, uint32_t interface)
{




	Ptr<Ipv4Route> ipv4RouteRetrans = Create<Ipv4Route>();
	ipv4RouteRetrans->SetDestination( Ipv4Address("7.0.0.2") );
//	ipv4RouteRetrans->SetGateway( Ipv4Address("7.0.0.2") );
	ipv4RouteRetrans->SetOutputDevice( ipv4->GetNetDevice(interface));
	ipv4RouteRetrans->SetSource( Ipv4Address("1.0.0.1") );

	Ptr<Packet> newpacket;


	uint16_t howmanyRetrans = (howmany_retrans < aLayerBuffer->GetN())? howmany_retrans:aLayerBuffer->GetN();

	for (uint16_t index = 0 ; index < howmanyRetrans; index++)
	{


		newpacket= aLayerBuffer->GetPacket(targetSeq);




//		uint8_t* tempBuf = 0;
//		newpacket->Serialize(tempBuf, 2);
//		if( *tempBuf == 0x0021)
//		{
//			newpacket->RemoveAtStart(2);
//		}


//		if( newpacket->GetSize() > 1492)
//		{
//			newpacket->RemoveAtStart(2);
//		}


		newpacket->Print(std::cout);

		std::cout <<  "SendRetransmission3:: packet size : " << newpacket->GetSize() << std::endl ;
		std::cout <<  "SendRetransmission3:: packet getlen : " << aLayerBuffer->GetLen(targetSeq) << std::endl ;
//		std::cout << " unpacking gtpIPheader  start!" <<std::endl;

		uint16_t tcpSize = aLayerBuffer->GetLen(targetSeq);


		Ipv4Header gtpIpv4Header;
		newpacket->PeekHeader(gtpIpv4Header);
		newpacket->RemoveHeader(gtpIpv4Header);
//		std::cout << " unpacking gtpIPheader  complete!" <<std::endl;

		UdpHeader gtpUdpHeader;
		newpacket->PeekHeader(gtpUdpHeader);
		newpacket->RemoveHeader(gtpUdpHeader);

		GtpuHeader gtpHeader;
		newpacket->PeekHeader(gtpHeader);
		newpacket->RemoveHeader(gtpHeader);

//		std::cout << " unpacking IPheader  start!" <<std::endl;
		Ipv4Header ipv4Header;
		newpacket->PeekHeader(ipv4Header);
		newpacket->RemoveHeader(ipv4Header);
		ipv4Header.SetDscp(Ipv4Header::DSCP_AF33);
//		std::cout << " unpacking IPheader  complete!" <<std::endl;


		std::cout << " do retransmission!!!@@@@@" << Simulator::Now()<<std::endl;

		TcpHeader tcpHeader;
		newpacket->PeekHeader(tcpHeader);
		newpacket->RemoveHeader(tcpHeader);



		newpacket->AddHeader(tcpHeader);
		newpacket->AddHeader(ipv4Header);
		newpacket->AddHeader(gtpHeader);
		newpacket->AddHeader(gtpUdpHeader);



		std::cout << "Retransmission index :" << index << "target seq: " << targetSeq << std::endl;
		ipv4->SendWithHeader(newpacket, gtpIpv4Header, ipv4RouteRetrans);
//		ipv4->Send(newpacket, Ipv4Address("1.0.0.1") , Ipv4Address("7.0.0.2") , (uint8_t) 6,  ipv4RouteRetrans);


		targetSeq += tcpSize;

		std::cout << " next target sequence : " << targetSeq << std::endl;
	}

	std::cout << " @@@@@@retransmission!!!  complete!" << Simulator::Now()<<std::endl;
}



uint16_t NeedRetrans ( SequenceNumber32 seq)
{
	bool isNeedRetrans = false;
	static SequenceNumber32 prevSeq(0);
//	static uint8_t howManyAck = 0;
//	static uint8_t RetransPeriod = 0;

	static unsigned int howManyAck = 0;
	static unsigned int RetransPeriod = 1;

//	howManyAck = 0;

	if( prevSeq == seq)
	{
		howManyAck++;
	}else
	{
		prevSeq = seq;
		howManyAck = 0;
		RetransPeriod = 1;
	}

//	std::cout << "Retransperiod-a :" << (RetransPeriod) << "    end"<< std::endl;
	std::cout << "howManyAck :" << (howManyAck) <<"    end"<< std::endl;
	std::cout << "Retransperiod :" << (RetransPeriod) <<"    end"<< std::endl;

	if(howManyAck >= ( RetransPeriod << 3 ))
	{
		isNeedRetrans = true;
//		std::cout << "Retransperiod-c :" << (RetransPeriod << 2 ) << std::endl;
		howManyAck = 0;
		RetransPeriod = RetransPeriod << 2 ;
	}


//	if(howManyAck >= (4 << RetransPeriod ))
//	{
//		isNeedRetrans = true;
//		std::cout << "Retransperiod :" << (4 << RetransPeriod ) << std::endl;
//		howManyAck = 0;
//		RetransPeriod = RetransPeriod + 2 ;
//	}

	return isNeedRetrans;

}




void RxPacketTrace( Ptr<const Packet> pkt, Ptr<Ipv4> ipv4, uint32_t interface )
{

	if (!enableEA)
		return;


	static uint16_t preAckAdWin = 50000;
	static Ipv4Header preIpv4Header;
	static TcpHeader preTcpHeader;
	static uint8_t preTcpFlag;

	uint16_t tempAckAdWin = 50000;
	Ipv4Header tempIpv4Header;
	uint16_t ipLen = 0;
	uint16_t tcpSize = 0;
	TcpHeader tempTcpHeader;
	uint8_t tempTcpFlag;

	static Ipv4Header gtpIpv4Header;
	static GtpuHeader gtpHeader;
	static UdpHeader gtpUdpHeader;

	Ipv4Header tempGtpIpv4Header;
	GtpuHeader tempGtpHeader;
	UdpHeader tempGtpUdpHeader;

	static SequenceNumber32 lastEAAck;

	static bool isFirstAck = true;
	static bool isZerowin = false ;



	Ptr<Packet> packet = pkt->Copy();
	Ptr<Packet> originPacket;





//	std::cout <<  "rxPacketTrace:: originPacketSize : " << pkt->GetSize() << std::endl ;


	/*111111*/

	packet->PeekHeader(tempGtpIpv4Header);
	packet->RemoveHeader(tempGtpIpv4Header);

	packet->PeekHeader(tempGtpUdpHeader);
	packet->RemoveHeader(tempGtpUdpHeader);

	packet->PeekHeader(tempGtpHeader);
	packet->RemoveHeader(tempGtpHeader);

	packet->PeekHeader(tempIpv4Header);
	packet->RemoveHeader(tempIpv4Header);

	packet->PeekHeader(tempTcpHeader);
	tempAckAdWin = tempTcpHeader.GetWindowSize();
	tempTcpFlag = tempTcpHeader.GetFlags();

	uint16_t targetRwin = tempTcpHeader.GetWindowSize();

	/*determine whether earlyack or retransmitted packet*/
	if( tempIpv4Header.GetDscp() == Ipv4Header::DSCP_AF13
			|| tempIpv4Header.GetDscp() == Ipv4Header::DSCP_AF23
			|| tempIpv4Header.GetDscp() == Ipv4Header::DSCP_AF33)
	{
		// do nothing for earlyack.. or local retransmission
//		ipv4->SetUp(interface);

		if( targetRwin*windowFactor <= 2000) //if the ack is zero window...
		{

			isZerowin = true;

		}



		return;
	}



	/******************* start.. rlc info *********************/
	Ptr<LteRlcUm> rlc = GetDrbRlc(enb_node, ue_node);

//	std::cout << Simulator::Now() <<":  current rlc buffer :  " << rlc->ReportBufferSize() << std::endl;
	fprintf(log_file, "%li\t%lu\t%s\n", Simulator::Now().GetMilliSeconds(),
			                              (long unsigned) rlc->ReportBufferSize(),
										  IsLos(enb_node->GetDevice(0), ue_node->GetDevice(0))?"Los":"NLos" );


	currentRlcBuf = rlc->ReportBufferSize();


	if ( currentRlcBuf >= rlcMax_ThreshBuf * target_bufRatio)
	{
		std::cout <<Simulator::Now() << "			: stop Early Ack... " << std::endl;

		fprintf(log_file, "%li\t%s\n", Simulator::Now().GetMilliSeconds(),": stop Early Ack..."  );



//		return;
	}
	/*******************  end.. rlc info *********************/





	if ( tempGtpIpv4Header.GetDestination().IsEqual( Ipv4Address("10.0.0.6")) ) //if ack packet...
	{


		if( tempTcpFlag == TcpHeader::SYN ||
			 tempTcpFlag == TcpHeader::RST ||
			 tempTcpFlag == TcpHeader::FIN ||
			 tempTcpFlag == TcpHeader::SYN + TcpHeader::ACK ||
			 tempTcpFlag == TcpHeader::RST + TcpHeader::ACK ||
			 tempTcpFlag == TcpHeader::FIN + TcpHeader::ACK )
		{

			windowFactor = tempTcpHeader.GetOption(TcpOption::WINSCALE)->GetObject<TcpOptionWinScale>()->GetScale();
			windowFactor = 2 << (windowFactor-1);
			std::cout << "winscale : " << windowFactor << std::endl;
			isFirstAck = true;
			return;
		}
		else
		{
			preAckAdWin = tempAckAdWin;
			preIpv4Header = tempIpv4Header;
			preTcpHeader = tempTcpHeader;
			preTcpFlag = tempTcpFlag;
			gtpIpv4Header = tempGtpIpv4Header;
			gtpUdpHeader = tempGtpUdpHeader;
			gtpUdpHeader.ForcePayloadSize(72);
			gtpHeader = tempGtpHeader;

			if(isFirstAck) // if this is sample ack packet...
			{
//				ipv4->SetUp(interface);
			}

			isFirstAck = false;


			SequenceNumber32 targetAck = tempTcpHeader.GetAckNumber();

			std::cout << " ACK num:" << targetAck << "    interface:  " <<interface << "  checksum :" << tempTcpHeader.IsChecksumOk() << "  time:"<< Simulator::Now()<<std::endl;
			std::cout << " BS_Rwin:" << (targetRwin*windowFactor) << std::endl;
//			if( targetRwin*windowFactor <= 2000) //if the ack is zero window...
//			{
//
//				isZerowin = true;
//				SendRetransmission( 1400, targetAck, ipv4, interface, preIpv4Header, preTcpHeader ,gtpIpv4Header, gtpUdpHeader, gtpHeader);
//
//				SendWinUpdate( packet , ipv4, interface,
//							   preIpv4Header, preTcpHeader, gtpIpv4Header,
//							   gtpHeader, gtpUdpHeader, lastEAAck);
//			}
//			else
//			{  // Zerowindow -> nonZeroWindow , allway retransmission
				if(isZerowin)
				{

//					SendRetransmission( 1400, targetAck, ipv4, interface, preIpv4Header, preTcpHeader ,gtpIpv4Header, gtpUdpHeader, gtpHeader);

					ipLen = tempIpv4Header.GetPayloadSize();

					SendWinUpdate( packet , ipv4, interface,
								   preIpv4Header, preTcpHeader, gtpIpv4Header,
								   gtpHeader, gtpUdpHeader, lastEAAck);


					isZerowin = false;
				}
//
//
//			}


			/*
			 * Test code start
			 *
			 * */
//			if ( targetAck > SequenceNumber32(200000) )
//			{
//				SendRetransmission3(targetAck,  ipv4, interface);
//			}

			/*
			 * Test code finish
			 *
			 * */

			if ( NeedRetrans(targetAck) )
			{


				uint16_t packetLength = aLayerBuffer->GetLen(targetAck);
				if( packetLength >0 )
				{
					std::cout << " need!!! retransmission!!!-------------------------" << Simulator::Now()<<std::endl;
					std::cout << "buffer info :"  << aLayerBuffer->GetN()<< "\t" << aLayerBuffer->Begin()->first << "\t" << ((aLayerBuffer->End()))->first << std::endl;
//					std::cout << "buffer info :"  << aLayerBuffer->GetN()<< "\t" << aLayerBuffer->Begin()->first << "\t" << ((aLayerBuffer->End()))->first << std::endl;


					SendRetransmission3(targetAck,  ipv4, interface);

				}else
				{

					std::cout << " need!!! retransmission!!!-----but it's not in an Alayer buffer" << Simulator::Now()<< std::endl;
					std::cout << "buffer info :"  << aLayerBuffer->GetN()<< "\t" << aLayerBuffer->Begin()->first << "\t" << aLayerBuffer->End()->first << std::endl;
					std::cout << "retransmissions from the first packet in a Alayer" << std::endl;
					targetAck = aLayerBuffer->Begin()->first;
					SendRetransmission3(targetAck,  ipv4, interface);
				}


//				SendWinUpdate( packet , ipv4, interface,
//							   preIpv4Header, preTcpHeader, gtpIpv4Header,
//							   gtpHeader, gtpUdpHeader, lastEAAck);


			}else
			{

				std::cout << " Receive Ack.. " << tempTcpHeader.GetAckNumber() << std::endl;
//				aLayerBuffer->Delete( aLayerBuffer->FindCloseTo(tempTcpHeader.GetAckNumber()) );
				aLayerBuffer->Delete( true , tempTcpHeader.GetAckNumber() );



			}


		}

	}
	else // if data packet...
	{
//		std::cout << "Rx data packet Trace" << std::endl;



		if( tempTcpFlag == TcpHeader::SYN ||
			 tempTcpFlag == TcpHeader::RST ||
			 tempTcpFlag == TcpHeader::FIN ||
			 tempTcpFlag == TcpHeader::SYN + TcpHeader::ACK ||
			 tempTcpFlag == TcpHeader::RST + TcpHeader::ACK ||
			 tempTcpFlag == TcpHeader::FIN + TcpHeader::ACK )
		{

			isFirstAck = true;
			return;
		}
		else
		{

			if(tempTcpHeader.GetSequenceNumber() > SequenceNumber32(2000) && tempTcpHeader.GetSequenceNumber() < SequenceNumber32(4000) )
			{
				sample_datapacket = pkt->Copy();

			}

			if( !isFirstAck )
			{


				ipLen = tempIpv4Header.GetPayloadSize();
				tcpSize = ipLen-tempTcpHeader.GetLength()*4;

//				aLayerBuffer->Insert(tempTcpHeader.GetSequenceNumber(), ipLen-tempTcpHeader.GetLength()*4);
//				originPacket->RemoveAtStart(1);
				originPacket = pkt->Copy();

//				std::cout << "data receiving.." << tempTcpHeader.GetSequenceNumber() <<std::endl;

				if ( aLayerBuffer->GetLen(tempTcpHeader.GetSequenceNumber()) > 0) // if it is already exist,,
				{

					std::cout << "duplicated data receiving.." << tempTcpHeader.GetSequenceNumber() <<std::endl;
					aLayerBuffer->Delete(false,tempTcpHeader.GetSequenceNumber() );
					aLayerBuffer->Insert( tempTcpHeader.GetSequenceNumber(), originPacket );


				}
				else
				{
					aLayerBuffer->Insert( tempTcpHeader.GetSequenceNumber(), originPacket );
				}


//				tempIpv4Header.Print( std::cout);
//				std::cout << "p" <<std::endl;

				/*modi_0627*/
				lastEAAck = tempTcpHeader.GetSequenceNumber() + tcpSize;
				/*modi_0627*/
				SendEarlyAck1( ipLen, packet , ipv4, interface ,
						       preAckAdWin, preIpv4Header, preTcpHeader, preTcpFlag ,
						       gtpIpv4Header, gtpHeader, gtpUdpHeader);
			}

		}



//		std::cout << "Alayer buffer's begin() seq: " << aLayerBuffer->Begin()->first << std::endl;
//		std::cout << "Alayer buffer's begin() len: " << aLayerBuffer->Begin()->second << std::endl;
//




	}




}



void RxPacketTraceConv( Ptr<const Packet> pkt, Ptr<Ipv4> ipv4, uint32_t interface )
{




	Ipv4Header tempIpv4Header;
	TcpHeader tempTcpHeader;
	uint8_t tempTcpFlag;


	Ipv4Header tempGtpIpv4Header;
	GtpuHeader tempGtpHeader;
	UdpHeader tempGtpUdpHeader;

	static SequenceNumber32 lastEAAck;



	Ptr<Packet> packet = pkt->Copy();

	packet->PeekHeader(tempGtpIpv4Header);
	packet->RemoveHeader(tempGtpIpv4Header);

	packet->PeekHeader(tempGtpUdpHeader);
	packet->RemoveHeader(tempGtpUdpHeader);

	packet->PeekHeader(tempGtpHeader);
	packet->RemoveHeader(tempGtpHeader);

	packet->PeekHeader(tempIpv4Header);
	packet->RemoveHeader(tempIpv4Header);

	packet->PeekHeader(tempTcpHeader);
	tempTcpFlag = tempTcpHeader.GetFlags();

	uint16_t targetRwin = tempTcpHeader.GetWindowSize();



	if ( tempGtpIpv4Header.GetDestination().IsEqual( Ipv4Address("10.0.0.6")) ) //if ack packet...
	{

		if( tempTcpFlag == TcpHeader::SYN ||
			 tempTcpFlag == TcpHeader::RST ||
			 tempTcpFlag == TcpHeader::FIN ||
			 tempTcpFlag == TcpHeader::SYN + TcpHeader::ACK ||
			 tempTcpFlag == TcpHeader::RST + TcpHeader::ACK ||
			 tempTcpFlag == TcpHeader::FIN + TcpHeader::ACK )
		{
			windowFactor = tempTcpHeader.GetOption(TcpOption::WINSCALE)->GetObject<TcpOptionWinScale>()->GetScale();
			windowFactor = 2 << (windowFactor-1);
			std::cout << "winscale : " << windowFactor << std::endl;
			return;
		}
		else
		{

			SequenceNumber32 targetAck = tempTcpHeader.GetAckNumber();

			std::cout << " ACK num:" << targetAck << "    interface:  " <<interface << "  checksum :" << tempTcpHeader.IsChecksumOk() << "  time:"<< Simulator::Now()<<std::endl;
			std::cout << " MS_Rwin:" << targetRwin*windowFactor << std::endl;


		}

	}
	else // if data packet...
	{
	}




}

void RxPacketTraceGW( Ptr<const Packet> pkt, Ptr<Ipv4> ipv4, uint32_t interface )
{


//	std::cout << "incoming GW interface :" << interface << std::endl;


	if (!enableEA)
		return;


	if(interface != 1) //if it is from server...
	{
		return;
	}

	ipv4->SetForwarding(1,true);

	Ipv4Header tempIpv4Header;
	TcpHeader tempTcpHeader;





	Ptr<Packet> packet = pkt->Copy();


	packet->PeekHeader(tempIpv4Header);
	packet->RemoveHeader(tempIpv4Header);

	packet->PeekHeader(tempTcpHeader);




	/*determine whether earlyack or retransmitted packet*/
	if( tempIpv4Header.GetDscp() == Ipv4Header::DSCP_AF13
			|| tempIpv4Header.GetDscp() == Ipv4Header::DSCP_AF23
			|| tempIpv4Header.GetDscp() == Ipv4Header::DSCP_AF33)
	{
		// no nothing for earlyack.. or local retransmission
//		ipv4->SetForwarding(interface,true);
		return;
	}



	if(tempTcpHeader.GetAckNumber() > SequenceNumber32(5000))
	{
		ipv4->SetForwarding(1,false);
	}

//	if ( tempGtpIpv4Header.GetDestination().IsEqual( Ipv4Address("1.0.0.1")) ) //if ack packet...
//	{
//
//
//		if(tempTcpHeader.GetAckNumber() > SequenceNumber32(5000))
//		{
//			ipv4->SetForwarding(interface,false);
//		}
//
//
//	}
//	else // if data packet...
//	{
//
//
//	}



}





void SpecialEvent(void)
{
	std::cout << "**********************************************************************************************************************" << std::endl;
	//p2p_2_h->SetDeviceAttribute ("DataRate", StringValue("1Mbps") );
//	p2p_2_h.SetDeviceAttribute("DataRate", StringValue("1kbps") );

	return;
}

void SpecialEvent1( Ptr<const Packet> pkt, const Address &address)
{
//	std::cout << "*****" << std::endl;

//	static uint32_t howmany = 0;

	Ipv4Header ipv4Header;
	TcpHeader tcpHeader;


	Ptr<Packet> packet = pkt->Copy();


//	packet->PeekHeader(ipv4Header);
//	packet->RemoveHeader(ipv4Header);
//	packet->PeekHeader(tcpHeader);

//	std::cout << "sequen num : " <<tcpHeader.GetSequenceNumber() << std::endl;

//	howmany++;
//	std::cout << "how many packets arrive at the ue application.. : " << howmany << std::endl;

	return;
}



void SpecialEvent2( Ptr<NetDevice> nd, Ptr<const Packet> pkt, uint16_t protocol, const Address &address)
//void SpecialEvent2( ns3::NetDevice::ReceiveCallback(Ptr<NetDevice> nd, Ptr<const Packet> pkt, uint16_t protocol, const Address &address))
{
	std::cout << "^^^^^" << std::endl;

	static uint32_t howmany = 0;

	Ipv4Header ipv4Header;
	TcpHeader tcpHeader;


//	Ptr<Packet> packet = pkt->Copy();


//	packet->PeekHeader(ipv4Header);
//	packet->RemoveHeader(ipv4Header);
//	packet->PeekHeader(tcpHeader);

//	std::cout << "sequen num : " <<tcpHeader.GetSequenceNumber() << std::endl;

	howmany++;
	std::cout << "how many packets arrive at the ue netdevice.. : " << howmany << std::endl;

	return;
}


void CourseChange( Ptr<const MobilityModel> model)
{

	std::cout << "position changed" << std::endl;
	Vector pos = model->GetPosition ();
	Vector vel = model->GetVelocity ();
	std::cout << Simulator::Now () << ", model=" << model << ", POS: x=" << pos.x << ", y=" << pos.y
			  << ", z=" << pos.z << "; VEL:" << vel.x << ", y=" << vel.y
			  << ", z=" << vel.z << std::endl;
}

void CurrentPosition(Ptr<ns3::MobilityModel> model)
{

	std::cout << "current position :"<< model->GetPosition() << "   at  "<<Simulator::Now()<< std::endl;

}

void CurrentRlcUmBufferSize(Ptr<Node> enb, Ptr<Node> ue)
{

	Ptr<MmWaveEnbNetDevice> mmWaveEnbNetDevice = enb->GetDevice(0)->GetObject<MmWaveEnbNetDevice>();
	Ptr<LteEnbRrc> lteEnbRrc = mmWaveEnbNetDevice->GetRrc();

//	Ptr<MmWaveUeNetDevice> mmWaveUeNetDevice = ue->GetObject<MmWaveUeNetDevice>();

	Ptr<MmWaveUeNetDevice> mmWaveUeNetDevice = ue->GetDevice(0)->GetObject<MmWaveUeNetDevice>();
	std::cout << "ue's N devices :  " << ue->GetNDevices() << std::endl;
	std::cout << "MmWaveEnbNetDevice type :  " << mmWaveEnbNetDevice->GetTypeId() << std::endl;

	uint64_t ueImsi = mmWaveUeNetDevice->GetImsi();
	uint16_t ueRnti = mmWaveUeNetDevice->GetRrc()->GetRnti();
	std::cout << "UE's Imsi :  " << ueImsi << std::endl;
	Ptr<UeManager> ueManager = lteEnbRrc->GetUeManager(ueRnti);

	ObjectPtrContainerValue tmpPtrCont;
	ueManager->GetAttribute("DataRadioBearerMap",tmpPtrCont);
	std::cout << " # of members in data rb map :  " << tmpPtrCont.GetN()    <<std::endl;
	Ptr<Object> tmpObject = tmpPtrCont.Get(1);
	std::cout << " 123123"    <<std::endl;
	Ptr<LteDataRadioBearerInfo> dataRadioBearer = tmpObject->GetObject<LteDataRadioBearerInfo>();

	std::cout << " DRB id :  " << dataRadioBearer->GetTypeId()    <<std::endl;

	Ptr<MmWaveEnbNetDevice> ueTargetEnb = mmWaveUeNetDevice->GetTargetEnb();
	if(mmWaveEnbNetDevice == ueTargetEnb)
	{

		std::cout << "The Target eNB is the eNB.....  " << std::endl;
	}else{
		std::cout << "The Target eNB is not the eNB.....  " << std::endl;
	}

	PointerValue tmpPtr;
	dataRadioBearer->GetAttribute("LteRlc",tmpPtr);
	tmpObject = tmpPtr.GetObject();
	Ptr<LteRlcUm> lteRlc = tmpObject->GetObject<LteRlcUm>();

	std::cout << "RLC info..."<< lteRlc->GetInstanceTypeId() << std::endl;
	std::cout << "RLC buffer info..."<< lteRlc->ReportBufferSize() << std::endl;
//	mmWaveEnbNetDevice->GetRrc()->get;
//	Ptr<LteRlc> rlcUm  = enb->GetObject<LteRlc>();
//
//	std::cout << "current buffer :"<< rlcUm->GetInstanceTypeId() << "   at  "<<Simulator::Now()<< std::endl;
//
//	std::cout << "report buffer size, complete!" << std::endl;
}







/**********************  Main function  ***********************/









int
main (int argc, char *argv[])
{



  /* preparing logging file
   * file name: mhTCP7_~~~~~.txt
   * */

  sprintf(fname, "mhTCP7_%s_B%dM_%s_RW%dM_d%dm", enableEA?"EA":"noEA", rlcMax_ThreshBuf/1000000 , dataRate.c_str(), rcvBufSize/1000000, distance);

  std::string fname_log="";
  fname_log.append(fname);
  fname_log.append("_log.txt");
  log_file = fopen(fname_log.c_str(), "w");





  /*Simulation parameters-for LTE*/
//  double distance = 60.0;


  /*Default configuration for simulation*/
//  tcp-procotol : NewReno
  if( tcpProtocol.compare("TcpNewReno") == 0)
  {
	  Config::SetDefault("ns3::TcpL4Protocol::SocketType", TypeIdValue( TcpNewReno::GetTypeId() ) );

  }
  else
  {
	  printf("TCP type error\n");
	  exit(1);
  }



//  Config::SetDefault("ns3::LteRlcUm::MaxTxBufferSize", UintegerValue(1024 * 1024 * 10));
  Config::SetDefault("ns3::LteRlcUm::MaxTxBufferSize", UintegerValue(rlcMax_ThreshBuf));



//
//  Config::SetDefault("/NodeList/*/$ns3::TcpL4Protocol/SocketList/*/RcvBufSize", UintegerValue(13107200));
//  Config::SetDefault("/NodeList/*/$ns3::TcpL4Protocol/SocketList/*/SndBufSize", UintegerValue(13107200));

  Config::SetDefault("ns3::TcpSocket::SndBufSize", UintegerValue(sndBufSize));
  Config::SetDefault("ns3::TcpSocket::RcvBufSize", UintegerValue(rcvBufSize));
  Config::SetDefault("ns3::TcpSocket::PersistTimeout", zeroWinProbeTime );



  /*Command line arguments*/
  CommandLine cmd;
  cmd.Parse(argc, argv);




  /*Create mmwave objects*/
  Ptr<MmWaveHelper> mmWave_h = CreateObject<MmWaveHelper>();

  mmWave_h->SetAttribute ("PathlossModel", StringValue ("ns3::BuildingsObstaclePropagationLossModel"));
  mmWave_h->Initialize();
  std::cout << "HARQ enable: " << mmWave_h->GetHarqEnabled() << std::endl;
  mmWave_h->SetHarqEnabled(true);
  std::cout << "HARQ enable: " << mmWave_h->GetHarqEnabled() << std::endl;
  BuildingsHelper building_h;


  Ptr<MmWavePointToPointEpcHelper> mmWaveEpc_h = CreateObject<MmWavePointToPointEpcHelper>();
  mmWave_h->SetEpcHelper(mmWaveEpc_h);

//  ConfigStore inputConfig;
//  inputConfig.ConfigureDefaults();


  Ptr<Node> pgw = mmWaveEpc_h->GetPgwNode();
//  Ptr<Node> enb = CreateObject<Node>();


  /*Create nodes*/
  Ptr<Node> server = CreateObject<Node>();
//  Ptr<Node> ue = CreateObject<Node>();
  NodeContainer ueNodes;
  NodeContainer enbNodes;
  enbNodes.Create(1);
  ueNodes.Create(1);

  /*install internet stack*/
  InternetStackHelper internetStack_h;
  internetStack_h.Install (server);



  /*Create the Internet attribute by using p2p helper*/
  PointToPointHelper p2pInet_h;
  p2pInet_h.SetDeviceAttribute ("DataRate", StringValue(bandwidthInet) );
  p2pInet_h.SetDeviceAttribute ("Mtu", UintegerValue (mtu));
  p2pInet_h.SetChannelAttribute ("Delay", StringValue(delay) );


  NetDeviceContainer server_pgw_ndc = p2pInet_h.Install (server,pgw);


  Ipv4AddressHelper ipv4addr_h;
  ipv4addr_h.SetBase ("1.0.0.0", "255.0.0.0");



  Ipv4InterfaceContainer internetIpv4_ic = ipv4addr_h.Assign (server_pgw_ndc);



  std::cout << "link0-0 : " << internetIpv4_ic.GetAddress(0) << std::endl; 	/*checking code*/
  std::cout << "link0-1 : " << internetIpv4_ic.GetAddress(1) << std::endl; 	/*checking code*/

  Ipv4Address serverAddr = internetIpv4_ic.GetAddress (0);
  std::cout << "server ipv4address : " << serverAddr << std::endl; 	/*checking code*/

  Ipv4StaticRoutingHelper staticRouting_h;
  Ptr<Ipv4StaticRouting> serverStaticRouting = staticRouting_h.GetStaticRouting (server->GetObject<Ipv4> ());
  serverStaticRouting->AddNetworkRouteTo (Ipv4Address ("7.0.0.0"), Ipv4Mask ("255.0.0.0"), 1);


  /* Print out routing table*/
//  std::cout << "server's route table : " << std::endl;
//  for (uint32_t i=0 ; i< staticRouting_h.GetStaticRouting(server->GetObject<Ipv4>())->GetNRoutes() ; i++)
//  {
//	  std::cout << "route table " << i << ":" << staticRouting_h.GetStaticRouting(server->GetObject<Ipv4>())->GetRoute(i) <<std::endl;
//  }


  /*Mobility configuration*/


  Ptr<ListPositionAllocator> enbPositionAlloc = CreateObject<ListPositionAllocator>();
  enbPositionAlloc->Add(enbPosition);
  MobilityHelper enbMobility_h;
  enbMobility_h.SetMobilityModel("ns3::ConstantPositionMobilityModel");
  enbMobility_h.SetPositionAllocator(enbPositionAlloc);
  enbMobility_h.Install(enbNodes);
  building_h.Install(enbNodes);

    std::cout << " enb mobility complete " << std::endl;

  MobilityHelper ueMobility_h;
//  Ptr<ListPositionAllocator> uePositionAlloc = CreateObject<ListPositionAllocator>();
//  uePositionAlloc->Add(Vector(0, 0, 0));
  ueMobility_h.SetMobilityModel("ns3::ConstantVelocityMobilityModel");
//  ueMobility_h.SetPositionAllocator(uePositionAlloc);
  ueMobility_h.Install(ueNodes);


  Ptr<ConstantVelocityMobilityModel> consVelocityModel = ueNodes.Get(0)->
		  	  	  	  	  	  	  	  	  GetObject<ConstantVelocityMobilityModel>();


  consVelocityModel->SetPosition(ueStarting);
  consVelocityModel->SetVelocity(ueVelocity);

  building_h.Install(ueNodes);

//  Box buildingPosition1 = Box(10,16,  5,10,  0,70);
//  Ptr<Building> building1 = CreateObject<Building>();
//  building1->SetBoundaries( buildingPosition1 );
//  building1->SetBuildingType( Building::Office );
//  building1->SetExtWallsType( Building::ConcreteWithoutWindows );
//  building1->SetNFloors(10);
//  Ptr<MobilityBuildingInfo> buildingInfo1 = CreateObject<MobilityBuildingInfo> (building1);
//  buildingInfo1->SetOutdoor();

  Box buildingPosition1 = Box(10,12,  5,10,  0,70);
//  Box buildingPosition1 = Box(10,1200,  5,10,  0,70); // NLOS for a long time

  Ptr<Building> building1 = CreateObject<Building>();
  building1->SetBoundaries( buildingPosition1 );
  building1->SetBuildingType( Building::Office );
  building1->SetExtWallsType( Building::ConcreteWithoutWindows );
  building1->SetNFloors(10);
  Ptr<MobilityBuildingInfo> buildingInfo1 = CreateObject<MobilityBuildingInfo> (building1);
  buildingInfo1->SetOutdoor();


  //building info
  Box buildingPosition2 = Box(16,20,  10,14,  0,70);
  Ptr<Building> building2 = CreateObject<Building>();
  building2->SetBoundaries( buildingPosition2 );
  building2->SetBuildingType( Building::Office );
  building2->SetExtWallsType( Building::ConcreteWithoutWindows );
  building2->SetNFloors(10);
  Ptr<MobilityBuildingInfo> buildingInfo2 = CreateObject<MobilityBuildingInfo> (building2);
  buildingInfo2->SetOutdoor();


  Box buildingPosition3 = Box(25,30,  5,8,  0,70);
  Ptr<Building> building3 = CreateObject<Building>();
  building3->SetBoundaries( buildingPosition3 );
  building3->SetBuildingType( Building::Office );
  building3->SetExtWallsType( Building::ConcreteWithoutWindows );
  building3->SetNFloors(10);
  Ptr<MobilityBuildingInfo> buildingInfo3 = CreateObject<MobilityBuildingInfo> (building3);
  buildingInfo3->SetOutdoor();


  Box buildingPosition4 = Box(32,36,  6,10,  0,70);
  Ptr<Building> building4 = CreateObject<Building>();
  building4->SetBoundaries( buildingPosition4 );
  building4->SetBuildingType( Building::Office );
  building4->SetExtWallsType( Building::ConcreteWithoutWindows );
  building4->SetNFloors(10);
  Ptr<MobilityBuildingInfo> buildingInfo4 = CreateObject<MobilityBuildingInfo> (building4);
  buildingInfo4->SetOutdoor();


  Box buildingPosition5 = Box(40,46,  6,10,  0,70);
  Ptr<Building> building5 = CreateObject<Building>();
  building5->SetBoundaries( buildingPosition5 );
  building5->SetBuildingType( Building::Office );
  building5->SetExtWallsType( Building::ConcreteWithoutWindows );
  building5->SetNFloors(10);
  Ptr<MobilityBuildingInfo> buildingInfo5 = CreateObject<MobilityBuildingInfo> (building5);
  buildingInfo5->SetOutdoor();


  Box buildingPosition6 = Box(48,54,  6,10,  0,70);
  Ptr<Building> building6 = CreateObject<Building>();
  building6->SetBoundaries( buildingPosition6 );
  building6->SetBuildingType( Building::Office );
  building6->SetExtWallsType( Building::ConcreteWithoutWindows );
  building6->SetNFloors(10);
  Ptr<MobilityBuildingInfo> buildingInfo6 = CreateObject<MobilityBuildingInfo> (building6);
  buildingInfo6->SetOutdoor();




  /*Configure LTE to enb and ue*/

  NetDeviceContainer enbLte_ndc = mmWave_h->InstallEnbDevice(enbNodes);

  NetDeviceContainer ueLte_ndc = mmWave_h->InstallUeDevice(ueNodes);

  internetStack_h.Install (ueNodes);



  /*Assign UE's IP and configure default GW*/

  Ipv4InterfaceContainer ueIp_if;
  ueIp_if = mmWaveEpc_h->AssignUeIpv4Address(ueLte_ndc);


  Ptr<Node> ue = ueNodes.Get (0);
  Ptr<Node> enb = enbNodes.Get (0);
  Ptr<Ipv4StaticRouting> ueStaticRouting = staticRouting_h.GetStaticRouting (ue->GetObject<Ipv4> ());
  ueStaticRouting->SetDefaultRoute( mmWaveEpc_h->GetUeDefaultGatewayAddress(), 1);



  /*Attach ue to enb*/

  mmWave_h->AttachToClosestEnb(ueLte_ndc,enbLte_ndc);


  /*Configure LTE other configuration*/
//  lte_h->SetSpectrumChannelAttribute("DataErrorModelEnabled", BooleanValue(false));
//  lte_h->SetSpectrumChannelAttribute("CtrlErrorModelEnabled", BooleanValue(false));




  /*Sink Application on UE*/

  uint16_t dlPort = 4380;
  Address ueSinkAddress ( InetSocketAddress( ueIp_if.GetAddress(0) , dlPort ) );
  PacketSinkHelper packetSink_h( "ns3::TcpSocketFactory", InetSocketAddress(Ipv4Address::GetAny(), dlPort ));


//  PcapHelperForIpv4::EnablePcapIpv4( "aa", ue->GetObject<Ipv4> (), uint(0), true );
  std::string fname_ue="";
  fname_ue.append(fname);
  fname_ue.append("_ue");
  internetStack_h.EnablePcapIpv4(fname_ue, ue->GetObject<Ipv4> (), 1 );
//  internetStack_h.enablep

  ApplicationContainer sink_ac = packetSink_h.Install(ue);
  sink_ac.Start( Seconds(0.));
  sink_ac.Stop( Seconds(simTime) );

//  Ptr<Socket> temp = sink_ac.Get(0)->GetObject<Socket>();
//  Ptr<TcpSocket> tcp_temp = DynamicCast<TcpSocket>(temp);
//
//  std::cout << "type of tcp_temp... : " << tcp_temp->GetTypeId() << std::endl ;
//  tcp_temp->SetAttribute("RcvBufSize", UintegerValue(262144));

//  Config::Set("/NodeList/1/$ns3::TcpSocket/RcvBufSize", UintegerValue(13107200) );
//  Config::Set("/NodeList/2/$ns3::TcpSocket/RcvBufSize", UintegerValue(13107200) );
//  Config::Set("/NodeList/3/$ns3::TcpSocket/RcvBufSize", UintegerValue(13107200) );

  /*Config::Set("/NodeList/1/$ns3::TcpL4Protocol/SocketList/0/RcvBufSize", UintegerValue(13107200));*/
//  Config::Set("/NodeList/2/$ns3::TcpL4Protocol/SocketList/0/RcvBufSize", UintegerValue(13107200));
//  Config::Set("/NodeList/3/$ns3::TcpL4Protocol/SocketList/0/RcvBufSize", UintegerValue(262144));


  std::cout << "how many devices server has... : " << server->GetNDevices() << std::endl ;
  std::cout << "how many devices enb has... : " << enb->GetNDevices() << std::endl ;
  std::cout << "how many devices ue has... : " << ue->GetNDevices() << std::endl ;

  Ptr<Ipv4L3Protocol> enb_ipv4L3 = enb->GetObject<Ipv4L3Protocol>();
  std::cout << "enb N-device : " << enb->GetNDevices() << std::endl;
  std::cout << "enb N-interface : " << enb_ipv4L3->GetNInterfaces() << std::endl;
  std::cout << "enb address : " << enb_ipv4L3->GetAddress(0,0) << std::endl;
  std::cout << "enb address : " << enb_ipv4L3->GetAddress(1,0) << std::endl;



  Ptr<Ipv4L3Protocol> ue_ipv4L3 = ue->GetObject<Ipv4L3Protocol>();
  std::cout << "ue N-device : " << ue->GetNDevices() << std::endl;
  std::cout << "ue N-interface : " << ue_ipv4L3->GetNInterfaces() << std::endl;
  std::cout << "ue address : " << ue_ipv4L3->GetAddress(0,0) << std::endl;
  std::cout << "ue address : " << ue_ipv4L3->GetAddress(1,0) << std::endl;

  Ptr<Ipv4L3Protocol> server_ipv4L3 = server->GetObject<Ipv4L3Protocol>();
  std::cout << "server N-device : " << server->GetNDevices() << std::endl;
  std::cout << "server N-interface : " << server_ipv4L3->GetNInterfaces() << std::endl;
  std::cout << "server address : " << server_ipv4L3->GetAddress(0,0) << std::endl;
  std::cout << "server address : " << server_ipv4L3->GetAddress(1,0) << std::endl;

  Ptr<Ipv4L3Protocol> pgw_ipv4L3 = pgw->GetObject<Ipv4L3Protocol>();
  std::cout << "pgw N-device : " << pgw->GetNDevices() << std::endl;
  std::cout << "pgw N-interface : " << pgw_ipv4L3->GetNInterfaces() << std::endl;
  std::cout << "pgw address : " << pgw_ipv4L3->GetAddress(0,0) << std::endl;
  std::cout << "pgw address : " << pgw_ipv4L3->GetAddress(1,0) << std::endl;
  std::cout << "pgw address : " << pgw_ipv4L3->GetAddress(2,0) << std::endl;
  std::cout << "pgw address : " << pgw_ipv4L3->GetAddress(3,0) << std::endl;


  /******************* RLC info test *********************/



//  Ptr<LteRlcUm> rlcUm = enbLte_ndc.Get(0)->GetObject<LteRlcUm>();
//  Ptr<LteRlcUm> rlcUm = enb->GetObject<LteRlcUm>();
//  std::cout << "kkt \t\t" << enbLte_ndc.Get(0)->GetTypeId() << std::endl;
//
//  std::cout << "kkt-0\t\t" << rlcUm->GetTypeId() << std::endl;



//  for (int index=1; index < 10;index++)
//  {
//	  std::cout << "kkt-" << index << std::endl;
//	  Simulator::Schedule (Seconds(index*0.1), &CurrentRlcUmBufferSize, rlcUm);
//  }


  /******************* RLC info test *********************/



/****************   test   *****************/
  // to change Netdevice buffer at eNB to make buffer over flow

  PointerValue tmp;
  enb->GetDevice(2)->GetAttribute("TxQueue", tmp);

  std::cout << "1111 : "  << std::endl;

  Ptr<Object> txQueue = tmp.GetObject();

  std::cout << "2222 : "  << std::endl;
//  Ptr<DropTailQueue> dtq
  UintegerValue limit;
  txQueue->GetAttribute("MaxPackets", limit);

  std::cout << "3333 : "  << std::endl;

  std::cout << "enb->GetDevice(2) : "<< enb->GetDevice(2)  << std::endl;
  std::cout << "enb_ipv4L3->GetNetDevice(1) : "<< enb_ipv4L3->GetNetDevice(1)  << std::endl;
  std::cout << "enb_ipv4L3->GetNetDevice(1) : "<< enb_ipv4L3->GetNetDevice(1)->GetIfIndex()  << std::endl;


  std::cout << "Maxpackets at enb net-device , before : " << limit.Get() << std::endl;

  txQueue->SetAttribute("MaxPackets", UintegerValue(basicQueueSize) );

  txQueue->GetAttribute("MaxPackets", limit);

  std::cout << "Maxpackets at enb net-device , after : " << limit.Get() << std::endl;


  server->GetDevice(1)->GetAttribute("TxQueue", tmp);
  txQueue = tmp.GetObject();
  txQueue->GetAttribute("MaxPackets", limit);
  std::cout << "Maxpackets at server net-device , after : " << limit.Get() << std::endl;






  ue->GetApplication(0)->TraceConnectWithoutContext("Rx", MakeCallback(&SpecialEvent1));


  /*Pump Application on Server*/
  Ptr<MyTcp> pump_ac = CreateObject<MyTcp>();
  Ptr<Socket> tcpSocket = Socket::CreateSocket(server, TcpSocketFactory::GetTypeId());

  tcpSocket->SetAttribute("SegmentSize", UintegerValue(segmentSize));

  pump_ac->Setup( tcpSocket, ueSinkAddress, packetSize, nPackets, DataRate(dataRate) );

  server->AddApplication(pump_ac);
  pump_ac->SetStartTime( Seconds(0.1));
  pump_ac->SetStopTime( Seconds(simTime) );


  std::string fname_wired="";
  fname_wired.append(fname);
  p2pInet_h.EnablePcapAll(fname_wired);

  std::string fname_cwnd="";
  fname_cwnd.append(fname);
  fname_cwnd.append("_cwnd");


  AsciiTraceHelper asciiTrace_h;
//  Ptr<OutputStreamWrapper> outStream = asciiTrace_h.CreateFileStream("MH-TCP_cwnd");
  Ptr<OutputStreamWrapper> outStream = asciiTrace_h.CreateFileStream(fname_cwnd);
  tcpSocket->TraceConnectWithoutContext("CongestionWindow" , MakeBoundCallback(&CwndChange, outStream));



  std::cout << "server node id : " << server->GetId() << std::endl;
  std::cout << "enb node id : " << enb->GetId() << std::endl;
  std::cout << "ue node id : " << ue->GetId() << std::endl;

  if(enableEA)
  {
	  Config::ConnectWithoutContext("/NodeList/2/$ns3::Ipv4L3Protocol/Rx", MakeCallback(&RxPacketTrace));
	  Config::ConnectWithoutContext("/NodeList/2/$ns3::Ipv4L3Protocol/Tx", MakeCallback(&RxPacketTrace));
	  Config::ConnectWithoutContext("/NodeList/0/$ns3::Ipv4L3Protocol/Rx", MakeCallback(&RxPacketTraceGW));
  }
  else
  {
	  Config::ConnectWithoutContext("/NodeList/2/$ns3::Ipv4L3Protocol/Tx", MakeCallback(&RxPacketTraceConv));
  }





  Config::Set("/NodeList/*/DeviceList/*/$ns3::SimpleNetDevice/TxQueue/$ns3::DropTailQueue/MaxPackets", UintegerValue(basicQueueSize));
  Config::Set("/NodeList/*/DeviceList/*/$ns3::PointToPointNetDevice/TxQueue/$ns3::DropTailQueue/MaxPackets", UintegerValue(basicQueueSize));


  /*Ue Mobility trace*/
  ueNodes.Get(0)->GetObject<MobilityModel>()->TraceConnectWithoutContext("CourseChange", MakeCallback(&CourseChange));

  AsciiTraceHelper ascii;
  ueMobility_h.EnableAsciiAll(ascii.CreateFileStream("MHtcp7 mobility trace.mob"));

  mmWave_h->EnableTraces();



  building_h.MakeMobilityModelConsistent();

//  Simulator::Schedule(Seconds(3), &SpecialEvent, p2p_2_h);
  std::cout << "starting position :" << ueNodes.Get(0)->GetObject<MobilityModel>()->GetPosition() <<std::endl;



  enb_node = enb;
  ue_node = ue;


//  Simulator::Schedule (Seconds(0.6), &CurrentRlcUmBufferSize, enb, ue);
//  Simulator::Schedule (Seconds(1.0), &CurrentPosition, ueNodes.Get(0)->GetObject<MobilityModel>());
//  Simulator::Schedule (Seconds(2.0), &CurrentPosition, ueNodes.Get(0)->GetObject<MobilityModel>());
//  Simulator::Schedule (Seconds(3.0), &CurrentPosition, ueNodes.Get(0)->GetObject<MobilityModel>());
//  Simulator::Schedule (Seconds(5), &CurrentPosition, ueNodes.Get(0)->GetObject<MobilityModel>());
//  Simulator::Schedule (Seconds(7), &CurrentPosition, ueNodes.Get(0)->GetObject<MobilityModel>());
//  Simulator::Schedule (Seconds(9), &CurrentPosition, ueNodes.Get(0)->GetObject<MobilityModel>());
//  Simulator::Schedule (Seconds(11), &CurrentPosition, ueNodes.Get(0)->GetObject<MobilityModel>());
//  Simulator::Schedule (Seconds(13), &CurrentPosition, ueNodes.Get(0)->GetObject<MobilityModel>());
//  Simulator::Schedule (Seconds(14), &CurrentPosition, ueNodes.Get(0)->GetObject<MobilityModel>());
//  Simulator::Schedule (Seconds(14.5), &CurrentPosition, ueNodes.Get(0)->GetObject<MobilityModel>());

  Simulator::Stop(Seconds(simTime));
  Simulator::Run();
  Simulator::Destroy();
//  std::cout << "starting position :" << ueNodes.Get(0)->GetObject<MobilityModel>()->GetPosition() <<std::endl;

  fflush(log_file);
  fclose(log_file);

  return 0;

}

