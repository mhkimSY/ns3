/*
 * Author: Minho Kim (mhkim@ramo.yonsei.ac.kr)
 * Yonsei Univ. in Seoul, South-Korea.
 * This is to simulate and analysis for wireless-TCP
 * MHtcp + buffer + LTE
 */


/*  warning of redefinition
#include "ns3/lte-helper.h"
#include "ns3/mmwave-helper.h"
#include "ns3/mmwave-point-to-point-epc-helper.h"
#include "ns3/epc-helper.h"
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/ipv4-global-routing-helper.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/lte-module.h"
#include "ns3/applications-module.h"
#include "ns3/point-to-point-helper.h"
#include "ns3/config-store.h"
*/



//#include "ns3/mmwave-helper.h"
//#include "ns3/mmwave-point-to-point-epc-helper.h"
//
//#include "ns3/core-module.h"
//#include "ns3/network-module.h"
//#include "ns3/ipv4-global-routing-helper.h"
//#include "ns3/internet-module.h"
//#include "ns3/mobility-module.h"
////#include "ns3/lte-module.h"
//#include "ns3/applications-module.h"
//#include "ns3/point-to-point-helper.h"
//#include "ns3/config-store.h"




#include "ns3/point-to-point-module.h"
#include "ns3/mmwave-helper.h"
#include "ns3/epc-helper.h"
#include "ns3/mmwave-point-to-point-epc-helper.h"
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/ipv4-global-routing-helper.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/applications-module.h"
#include "ns3/point-to-point-helper.h"
#include "ns3/config-store.h"

#include "ns3/epc-gtpu-header.h"

/*
 *
 *     Server ----------[PGW]---------------[eNB]---------------UE
 *     1.0.0.1       1.0.0.2                                           7.0.0.2
 *
 *
 *
 * */


using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("mhtcp3");



 /*MyTcp application on server*/

class MyTcp : public Application
{
public:
	MyTcp();
	virtual ~MyTcp();

	void Setup (Ptr<Socket> socket, Address address, uint32_t packetSize, uint32_t nPackets, DataRate dataRate);

private:
	virtual void StartApplication(void);
	virtual void StopApplication(void);
	void ScheduledTx(void);
	void SendPacket(void);

	Ptr<Socket> m_socket;
	Address m_peer;
	uint32_t m_packetSize;
	uint32_t m_nPackets;
	DataRate m_dataRate;
	EventId m_sendEvent;
	bool m_running;
	uint32_t m_packetsSent;

};

MyTcp::MyTcp()
	: m_socket(0),
	  m_peer(),
	  m_packetSize(0),
	  m_nPackets(0),
	  m_dataRate(0),
	  m_sendEvent(),
	  m_running(false),
	  m_packetsSent(0)
{

}

MyTcp::~MyTcp()
{
	m_socket=0;
}

void MyTcp::Setup(Ptr<Socket> socket, Address address, uint32_t packetSize, uint32_t nPackets, DataRate dataRate)
{
	m_socket = socket;
	m_peer = address;
	m_packetSize = packetSize;
	m_nPackets = nPackets;
	m_dataRate = dataRate;
}


void MyTcp::StartApplication(void)
{
	m_running = true;
	m_packetsSent = 0;
	m_socket->Bind();
	m_socket->Connect(m_peer);
	SendPacket();
}

void MyTcp::StopApplication(void)
{
	m_running = false;

	if(m_sendEvent.IsRunning())
	{
		Simulator::Cancel(m_sendEvent);
	}

	if(m_socket)
	{
		m_socket->Close();
	}
}

void MyTcp::ScheduledTx(void)
{
	if( m_running)
	{
		Time tNext( Seconds(m_packetSize * 8 / static_cast<double> (m_dataRate.GetBitRate() ) ));
		m_sendEvent = Simulator::Schedule( tNext , &MyTcp::SendPacket , this );
	}

}

void MyTcp::SendPacket(void)
{
/*	Ptr<Packet> packet = Create<Packet> (m_packetSize);
	m_socket->Send(packet);

	NS_LOG_DEBUG ("Sending:    "<<m_packetsSent << "\t" << Simulator::Now ().GetSeconds ());
	std::cout << "Sending:    " <<m_packetsSent << "\t" << Simulator::Now ().GetSeconds ()<<std::endl;

	if( ++m_packetsSent < m_nPackets)
	{
		ScheduledTx();
	}*/

	static int send_num = 0;
	Ptr<Packet> packet = Create<Packet> (m_packetSize);
	m_socket->Send (packet);
	NS_LOG_DEBUG ("Sending:    "<<send_num++ << "\t" << Simulator::Now ().GetSeconds ());
	std::cout << "Sending:    " <<++send_num << "\t" << Simulator::Now ().GetSeconds ()<<std::endl;

  	if (++m_packetsSent < m_nPackets)
	{
	    ScheduledTx ();
	}
}






static void CwndChange (Ptr<OutputStreamWrapper> stream, uint32_t oldCwnd, uint32_t newCwnd )
{
	*stream->GetStream() << Simulator::Now().GetSeconds() << "\t" << oldCwnd << "\t" << newCwnd << std::endl ;
}






void SendEarlyAck( Ptr<Packet> dataPacket, Ptr<Ipv4> ipv4, uint32_t interface
			,uint16_t preAckWin , Ipv4Header preIpv4Heaer, TcpHeader preTcpHeader, uint8_t preTcpFlag,
			Ipv4Header gtpIpv4Header, GtpuHeader gtpHeader, UdpHeader gtpUdpHeader)
{
	static bool enableEA = true;
	if (!enableEA)
		return;

	Ipv4Header ipv4Header; //original header of data
	Ipv4Header ipv4HeaderEA; // Early Ack header corresponding to received data
	static SequenceNumber32 earlyAckedSeq(0);



	dataPacket->PeekHeader(ipv4Header);
	ipv4HeaderEA = preIpv4Heaer;



	Ipv4Address destination = ipv4Header.GetDestination();
	Ipv4Address source = ipv4Header.GetSource();
	uint16_t tcpTotalSize = ipv4Header.GetPayloadSize() ; //tcplayload - ipheadersize



	ipv4HeaderEA.SetDestination(source);// exchange ipv4 addresses
	ipv4HeaderEA.SetSource(destination);
	ipv4HeaderEA.EnableChecksum();

	Ptr<Ipv4Route> ipv4RouteEA = Create<Ipv4Route>();
	ipv4RouteEA->SetDestination(source);
	ipv4RouteEA->SetGateway(source);
	ipv4RouteEA->SetOutputDevice( ipv4->GetNetDevice(interface)); // send back to the interface where it comes from
	ipv4RouteEA->SetSource(destination);

	dataPacket->RemoveHeader(ipv4Header); //delete duplicated ipv4 header

	TcpHeader tcpHeader;
	TcpHeader tcpHeaderEA;

	dataPacket->PeekHeader(tcpHeader);
	tcpHeaderEA = preTcpHeader;

	if (tcpHeader.GetFlags() == 2)// if it's SYN,,
	{
		return;
	}

	SequenceNumber32 dataSeqNum = tcpHeader.GetSequenceNumber();

	uint16_t dataSrcPort = tcpHeader.GetSourcePort();
	uint16_t dataDstPort = tcpHeader.GetDestinationPort();
	uint32_t tcpHeaderSize = tcpHeader.GetSerializedSize();
	uint16_t tcpdatasize = tcpTotalSize - tcpHeaderSize; //for calculate ack num for data

	tcpHeaderEA.SetAckNumber(dataSeqNum + tcpdatasize);
	tcpHeaderEA.SetDestinationPort(dataSrcPort);
	tcpHeaderEA.SetSourcePort(dataDstPort);
	tcpHeaderEA.EnableChecksums();

	Ptr<Packet> newpacket = Create<Packet>(0);
	newpacket->AddHeader(tcpHeaderEA);



	if( interface == 1)
	{
		// for packets from server to ue
		if( preTcpFlag != 18 && earlyAckedSeq!=tcpHeaderEA.GetAckNumber() )
		{
			ipv4->SendWithHeader(newpacket, ipv4HeaderEA, ipv4RouteEA);
			earlyAckedSeq = tcpHeaderEA.GetAckNumber();
			return;
		}


	}
	if( interface == 2)
	{
		// for packets from server to ue
		if( preTcpFlag != 18 && earlyAckedSeq!=tcpHeaderEA.GetAckNumber() )
		{

			earlyAckedSeq = tcpHeaderEA.GetAckNumber();
			ipv4->SetForwarding(interface,false);
			return;
		}


	}
}


void SendEarlyAck1( Ptr<Packet> dataPacket, Ptr<Ipv4> ipv4, uint32_t interface
			,uint16_t preAckWin , Ipv4Header preIpv4Header, TcpHeader preTcpHeader, uint8_t preTcpFlag,
			Ipv4Header gtpIpv4Header, GtpuHeader gtpHeader, UdpHeader gtpUdpHeader)
{
	static bool enableEA = true;
	if (!enableEA)
		return;

//	std::cout << "Early Ack has been generated" << std::endl;

	Ipv4Header ipv4HeaderEA; // Early Ack header corresponding to received data
	ipv4HeaderEA = preIpv4Header;
	static SequenceNumber32 earlyAckedSeq(0);


	uint16_t tcpTotalSize = dataPacket->GetSerializedSize();




	gtpIpv4Header.EnableChecksum();

	Ptr<Ipv4Route> ipv4RouteEA = Create<Ipv4Route>();
	ipv4RouteEA->SetDestination( gtpIpv4Header.GetDestination() );
	ipv4RouteEA->SetGateway( gtpIpv4Header.GetDestination() );
	ipv4RouteEA->SetOutputDevice( ipv4->GetNetDevice(interface)); // send back to the interface where it comes from
	ipv4RouteEA->SetSource( gtpIpv4Header.GetSource() );


	TcpHeader originTcpHeader;
	TcpHeader tcpHeaderEA;

	dataPacket->PeekHeader(originTcpHeader);
	tcpHeaderEA = preTcpHeader;


	SequenceNumber32 dataSeqNum = originTcpHeader.GetSequenceNumber();
	uint32_t tcpHeaderSize = originTcpHeader.GetSerializedSize();
	uint16_t tcpdatasize = tcpTotalSize - tcpHeaderSize; //for calculate ack num for data

	tcpHeaderEA.SetAckNumber(dataSeqNum + tcpdatasize);

	tcpHeaderEA.EnableChecksums();

	dataPacket->RemoveHeader(originTcpHeader);
	Ptr<Packet> newpacket = Create<Packet>(0);
	newpacket->AddHeader(tcpHeaderEA);
	newpacket->AddHeader(ipv4HeaderEA);
	newpacket->AddHeader(gtpHeader);
	newpacket->AddHeader(gtpUdpHeader);


	ipv4->SendWithHeader(newpacket, gtpIpv4Header, ipv4RouteEA);
	earlyAckedSeq = tcpHeaderEA.GetAckNumber();


}


void RxPacketTrace( Ptr<const Packet> pkt, Ptr<Ipv4> ipv4, uint32_t interface )
{

	static uint16_t preAckAdWin = 50000;
	static Ipv4Header preIpv4Header;
	static TcpHeader preTcpHeader;
	static uint8_t preTcpFlag;

	uint16_t tempAckAdWin = 50000;
	Ipv4Header tempIpv4Header;
	TcpHeader tempTcpHeader;
	uint8_t tempTcpFlag;

	static Ipv4Header gtpIpv4Header;
	static GtpuHeader gtpHeader;
	static UdpHeader gtpUdpHeader;

	Ipv4Header tempGtpIpv4Header;
	GtpuHeader tempGtpHeader;
	UdpHeader tempGtpUdpHeader;

	static bool isFirstAck = true;


	ipv4->SetForwarding(interface,true);


	Ptr<Packet> packet = pkt->Copy();



	packet->PeekHeader(tempGtpIpv4Header);
	packet->RemoveHeader(tempGtpIpv4Header);

	packet->PeekHeader(tempGtpUdpHeader);
	packet->RemoveHeader(tempGtpUdpHeader);

	packet->PeekHeader(tempGtpHeader);
	packet->RemoveHeader(tempGtpHeader);

	packet->PeekHeader(tempIpv4Header);
	packet->RemoveHeader(tempIpv4Header);

	packet->PeekHeader(tempTcpHeader);
	tempAckAdWin = tempTcpHeader.GetWindowSize();
	tempTcpFlag = tempTcpHeader.GetFlags();


	if ( tempGtpIpv4Header.GetDestination().IsEqual( Ipv4Address("10.0.0.6")) ) //if ack packet...
	{
//		std::cout << "Rx ack packet Trace" << std::endl;

		if( tempTcpFlag == TcpHeader::SYN ||
			 tempTcpFlag == TcpHeader::RST ||
			 tempTcpFlag == TcpHeader::FIN ||
			 tempTcpFlag == TcpHeader::SYN + TcpHeader::ACK ||
			 tempTcpFlag == TcpHeader::RST + TcpHeader::ACK ||
			 tempTcpFlag == TcpHeader::FIN + TcpHeader::ACK )
		{
			isFirstAck = true;
			return;
		}
		else
		{
			preAckAdWin = tempAckAdWin;
			preIpv4Header = tempIpv4Header;
			preTcpHeader = tempTcpHeader;
			preTcpFlag = tempTcpFlag;
			gtpIpv4Header = tempGtpIpv4Header;
			gtpUdpHeader = tempGtpUdpHeader;
			gtpUdpHeader.ForcePayloadSize(72);
			gtpHeader = tempGtpHeader;
			isFirstAck = false;

		}

	}
	else // if data packet...
	{
//		std::cout << "Rx data packet Trace" << std::endl;

		if( tempTcpFlag == TcpHeader::SYN ||
			 tempTcpFlag == TcpHeader::RST ||
			 tempTcpFlag == TcpHeader::FIN ||
			 tempTcpFlag == TcpHeader::SYN + TcpHeader::ACK ||
			 tempTcpFlag == TcpHeader::RST + TcpHeader::ACK ||
			 tempTcpFlag == TcpHeader::FIN + TcpHeader::ACK )
		{
			isFirstAck = true;
			return;
		}
		else
		{
			if( !isFirstAck )
			{
				SendEarlyAck1( packet , ipv4, interface ,
						       preAckAdWin, preIpv4Header, preTcpHeader, preTcpFlag ,
						       gtpIpv4Header, gtpHeader, gtpUdpHeader);
			}

		}


	}




}






void SpecialEvent(void)
{
	std::cout << "**********************************************************************************************************************" << std::endl;
	//p2p_2_h->SetDeviceAttribute ("DataRate", StringValue("1Mbps") );
//	p2p_2_h.SetDeviceAttribute("DataRate", StringValue("1kbps") );

	return;
}

void SpecialEvent1( Ptr<const Packet> pkt, const Address &address)
{
//	std::cout << "*****" << std::endl;

//	static uint32_t howmany = 0;

	Ipv4Header ipv4Header;
	TcpHeader tcpHeader;


	Ptr<Packet> packet = pkt->Copy();


//	packet->PeekHeader(ipv4Header);
//	packet->RemoveHeader(ipv4Header);
//	packet->PeekHeader(tcpHeader);

//	std::cout << "sequen num : " <<tcpHeader.GetSequenceNumber() << std::endl;

//	howmany++;
//	std::cout << "how many packets arrive at the ue application.. : " << howmany << std::endl;

	return;
}



void SpecialEvent2( Ptr<NetDevice> nd, Ptr<const Packet> pkt, uint16_t protocol, const Address &address)
//void SpecialEvent2( ns3::NetDevice::ReceiveCallback(Ptr<NetDevice> nd, Ptr<const Packet> pkt, uint16_t protocol, const Address &address))
{
	std::cout << "^^^^^" << std::endl;

	static uint32_t howmany = 0;

	Ipv4Header ipv4Header;
	TcpHeader tcpHeader;


//	Ptr<Packet> packet = pkt->Copy();


//	packet->PeekHeader(ipv4Header);
//	packet->RemoveHeader(ipv4Header);
//	packet->PeekHeader(tcpHeader);

//	std::cout << "sequen num : " <<tcpHeader.GetSequenceNumber() << std::endl;

	howmany++;
	std::cout << "how many packets arrive at the ue netdevice.. : " << howmany << std::endl;

	return;
}










/**********************  Main function  ***********************/









int
main (int argc, char *argv[])
{
  /*Simulation parameters*/
  double simTime = 5.0 ;
  std::string tcpProtocol = "TcpNewReno";

  std::string bandwidthInet = "100Gb/s";
  std::string bandwidthBsUe = "100Gb/s";
  int mtu = 1500;
  uint32_t packetSize = 1400;
  uint32_t segmentSize = 1400;
  uint32_t nPackets = 10000;
  std::string dataRate = "25Mbps";
  std::string delay = "5ms";
  std::string delayBsUe = "20ms";


//  double errorRate = 0.0;
  int basicQueueSize = 200; // num of packets
//  int queueSizeBS = 2;


  /*Simulation parameters-for LTE*/
  double distance = 60.0;


  /*Default configuration for simulation*/
//  tcp-procotol : NewReno
  if( tcpProtocol.compare("TcpNewReno") == 0)
  {
	  Config::SetDefault("ns3::TcpL4Protocol::SocketType", TypeIdValue( TcpNewReno::GetTypeId() ) );

  }
  else
  {
	  printf("TCP type error\n");
	  exit(1);
  }
  Config::SetDefault("ns3::DropTailQueue::MaxPackets", UintegerValue( uint32_t(basicQueueSize)));

  Config::SetDefault("ns3::LteRlcUm::MaxTxBufferSize", UintegerValue(1024 * 1024));

  /*Command line arguments*/
  CommandLine cmd;
  cmd.Parse(argc, argv);







  /*Create LTE objects*/
//  Ptr<LteHelper> lte_h = CreateObject<LteHelper>();
//  Ptr<PointToPointEpcHelper> epc_h = CreateObject<PointToPointEpcHelper>();
//  lte_h->SetEpcHelper(epc_h);
//  Ptr<Node> pgw = epc_h->GetPgwNode();
//  Ptr<Node> enb = CreateObject<Node>();



  /*Create mmwave objects*/
  Ptr<MmWaveHelper> mmWave_h = CreateObject<MmWaveHelper>();
  Ptr<MmWavePointToPointEpcHelper> mmWaveEpc_h = CreateObject<MmWavePointToPointEpcHelper>();
  mmWave_h->SetEpcHelper(mmWaveEpc_h);

  ConfigStore inputConfig;
  inputConfig.ConfigureDefaults();


  Ptr<Node> pgw = mmWaveEpc_h->GetPgwNode();
//  Ptr<Node> enb = CreateObject<Node>();


  /*Create nodes*/
  Ptr<Node> server = CreateObject<Node>();
//  Ptr<Node> ue = CreateObject<Node>();
  NodeContainer ueNodes;
  NodeContainer enbNodes;
  enbNodes.Create(1);
  ueNodes.Create(1);

  /*install internet stack*/
  InternetStackHelper internetStack_h;
  internetStack_h.Install (server);



  /*Create the Internet attribute by using p2p helper*/
  PointToPointHelper p2pInet_h;
  p2pInet_h.SetDeviceAttribute ("DataRate", StringValue(bandwidthInet) );
  p2pInet_h.SetDeviceAttribute ("Mtu", UintegerValue (mtu));
  p2pInet_h.SetChannelAttribute ("Delay", StringValue(delay) );


  NetDeviceContainer server_pgw_ndc = p2pInet_h.Install (server,pgw);


  Ipv4AddressHelper ipv4addr_h;
  ipv4addr_h.SetBase ("1.0.0.0", "255.0.0.0");



  Ipv4InterfaceContainer internetIpv4_ic = ipv4addr_h.Assign (server_pgw_ndc);



  std::cout << "link0-0 : " << internetIpv4_ic.GetAddress(0) << std::endl; 	/*checking code*/
  std::cout << "link0-1 : " << internetIpv4_ic.GetAddress(1) << std::endl; 	/*checking code*/

  Ipv4Address serverAddr = internetIpv4_ic.GetAddress (0);
  std::cout << "server ipv4address : " << serverAddr << std::endl; 	/*checking code*/

  Ipv4StaticRoutingHelper staticRouting_h;
  Ptr<Ipv4StaticRouting> serverStaticRouting = staticRouting_h.GetStaticRouting (server->GetObject<Ipv4> ());
  serverStaticRouting->AddNetworkRouteTo (Ipv4Address ("7.0.0.0"), Ipv4Mask ("255.0.0.0"), 1);


  /* Print out routing table*/
  std::cout << "server's route table : " << std::endl;
  for (uint32_t i=0 ; i< staticRouting_h.GetStaticRouting(server->GetObject<Ipv4>())->GetNRoutes() ; i++)
  {
	  std::cout << "route table " << i << ":" << staticRouting_h.GetStaticRouting(server->GetObject<Ipv4>())->GetRoute(i) <<std::endl;
  }


  /*Mobility configuration*/

  Ptr<ListPositionAllocator> positionAlloc = CreateObject<ListPositionAllocator>();
  positionAlloc->Add(Vector(distance*0, 0, 0));
  positionAlloc->Add(Vector(distance*0+10, 0, 0));

  MobilityHelper mobility_h;
  mobility_h.SetMobilityModel("ns3::ConstantPositionMobilityModel");
  mobility_h.SetPositionAllocator(positionAlloc);
  mobility_h.Install(enbNodes);
  mobility_h.Install(ueNodes);


  std::cout << "11111111111"<< std::endl ;

  /*Configure LTE to enb and ue*/

  NetDeviceContainer enbLte_ndc = mmWave_h->InstallEnbDevice(enbNodes);

  std::cout << "222222222222"<< std::endl ;
  NetDeviceContainer ueLte_ndc = mmWave_h->InstallUeDevice(ueNodes);


  internetStack_h.Install (ueNodes);



  std::cout << "3333333333333"<< std::endl ;


  /*Assign UE's IP and configure default GW*/

  Ipv4InterfaceContainer ueIp_if;
  ueIp_if = mmWaveEpc_h->AssignUeIpv4Address(ueLte_ndc);

  std::cout << "444"<< std::endl ;

  Ptr<Node> ue = ueNodes.Get (0);
  std::cout << "454"<< std::endl ;
  Ptr<Node> enb = enbNodes.Get (0);
  std::cout << "464"<< std::endl ;
  Ptr<Ipv4StaticRouting> ueStaticRouting = staticRouting_h.GetStaticRouting (ue->GetObject<Ipv4> ());
  ueStaticRouting->SetDefaultRoute( mmWaveEpc_h->GetUeDefaultGatewayAddress(), 1);

  std::cout << "555"<< std::endl ;

  /*Attach ue to enb*/
//  mmWave_h->Attach(ueLte_ndc.Get(0),enbLte_ndc.Get(0));

  mmWave_h->AttachToClosestEnb(ueLte_ndc,enbLte_ndc);


  /*Configure LTE other configuration*/
//  lte_h->SetSpectrumChannelAttribute("DataErrorModelEnabled", BooleanValue(false));
//  lte_h->SetSpectrumChannelAttribute("CtrlErrorModelEnabled", BooleanValue(false));







  uint16_t dlPort = 4380;
//  uint16_t ulPort = 4381;

  /*Sink Application on UE*/
  Address ueSinkAddress ( InetSocketAddress( ueIp_if.GetAddress(0) , dlPort ) );
  PacketSinkHelper packetSink_h( "ns3::TcpSocketFactory", InetSocketAddress(Ipv4Address::GetAny(), dlPort ));

  std::cout << "UE0 : " << ueIp_if.GetAddress(0) << std::endl ; /*checking code*/

  ApplicationContainer sink_ac = packetSink_h.Install(ue);
  sink_ac.Start( Seconds(0.));
  sink_ac.Stop( Seconds(simTime) );

  ue->GetApplication(0)->TraceConnectWithoutContext("Rx", MakeCallback(&SpecialEvent1));


  /*Pump Application on Server*/
  Ptr<MyTcp> pump_ac = CreateObject<MyTcp>();
  Ptr<Socket> tcpSocket = Socket::CreateSocket(server, TcpSocketFactory::GetTypeId());

  tcpSocket->SetAttribute("SegmentSize", UintegerValue(segmentSize));

  pump_ac->Setup( tcpSocket, ueSinkAddress, packetSize, nPackets, DataRate(dataRate) );


  server->AddApplication(pump_ac);
  pump_ac->SetStartTime( Seconds(0.5));
  pump_ac->SetStopTime( Seconds(simTime) );



  AsciiTraceHelper asciiTrace_h;
  Ptr<OutputStreamWrapper> outStream = asciiTrace_h.CreateFileStream("MH-TCP_cwnd");
  tcpSocket->TraceConnectWithoutContext("CongestionWindow" , MakeBoundCallback(&CwndChange, outStream));

  p2pInet_h.EnablePcapAll("MHTCP-wireless-");

  std::cout << "enb node id : " << enb->GetId() << std::endl;
  std::cout << "ue node id : " << ue->GetId() << std::endl;
  std::cout << "enb node interface 0,0 : " << enb->GetObject<Ipv4>()->GetAddress(0,0) << std::endl;
  std::cout << "enb node interface 1,0 : " << enb->GetObject<Ipv4>()->GetAddress(1,0) << std::endl;


  Config::ConnectWithoutContext("/NodeList/2/$ns3::Ipv4L3Protocol/Rx", MakeCallback(&RxPacketTrace));
  Config::ConnectWithoutContext("/NodeList/2/$ns3::Ipv4L3Protocol/Tx", MakeCallback(&RxPacketTrace));



//  Simulator::Schedule(Seconds(3), &SpecialEvent, p2p_2_h);
  Simulator::Stop(Seconds(simTime));
  Simulator::Run();
  Simulator::Destroy();
  return 0;

}

