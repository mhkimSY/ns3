/*
 * Author: Minho Kim (mhkim@ramo.yonsei.ac.kr)
 * Yonsei Univ. in Seoul, South-Korea.
 * This is to simulate and analysis for wireless-TCP
 */


#include "ns3/lte-helper.h"
#include "ns3/epc-helper.h"
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/ipv4-global-routing-helper.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/lte-module.h"
#include "ns3/applications-module.h"
#include "ns3/point-to-point-helper.h"
#include "ns3/config-store.h"
//#include "ns3/gtk-config-store.h"

/*
 *                      EPC
 *     Server -----[PGW --- SGW]--------eNB--------UE
 *     1.0.0.1       1.0.0.2   7.0.0.1      7.0.0.2     7.0.0.3
 *
 *
 *
 * */


using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("mhtcp0");

int
main (int argc, char *argv[])
{
  /*Simulation parameter*/
  double simTime = 5.0 ;
  double distance = 60.0;
//  double interPacketInterval = 1000;

  /*Command line arguments*/
  CommandLine cmd;
  cmd.Parse(argc, argv);

  Ptr<LteHelper> lte_h = CreateObject<LteHelper> ();
  Ptr<PointToPointEpcHelper>  epc_h = CreateObject<PointToPointEpcHelper> ();
  lte_h->SetEpcHelper (epc_h);

//  ConfigStore inputConfig;
//  inputConfig.ConfigureDefaults();
  Config::SetDefault("ns3::TcpL4Protocol::SocketType", TypeIdValue(TcpNewReno::GetTypeId()));

  Ptr<Node> pgw = epc_h->GetPgwNode();

  /*Create a server*/
//  NodeContainer remoteHostContainer;
//  remoteHostContainer.Create (1);
//  Ptr<Node> remoteHost = remoteHostContainer.Get (0);
  Ptr<Node> server = CreateObject<Node>();

  InternetStackHelper internetStack_h;
  internetStack_h.Install (server);

  /*Create the Internet attribute by using p2p-helper*/
  PointToPointHelper p2p_h;
  p2p_h.SetDeviceAttribute ("DataRate", DataRateValue (DataRate (100000000))); //100Mbps
  p2p_h.SetDeviceAttribute ("Mtu", UintegerValue (1500));
  p2p_h.SetChannelAttribute ("Delay", TimeValue (Seconds (0.050)));
//  NetDeviceContainer internetDevices = p2p_h.Install (pgw, server);
  NetDeviceContainer server2pgw_ndc = p2p_h.Install (server,pgw);


  std::cout << "get0 : " << server2pgw_ndc.Get(0) << std::endl; 	/*checking code*/
  std::cout << "get1 : " << server2pgw_ndc.Get(1) << std::endl; 	/*checking code*/
  std::cout << "server_nd0 : " << server->GetDevice(0) << std::endl; 	/*checking code*/
  std::cout << "server_nd1 : " << server->GetDevice(1) << std::endl; 	/*checking code*/


//  Ipv4AddressHelper ipv4h;
  Ipv4AddressHelper ipv4addr_h;
  ipv4addr_h.SetBase ("1.0.0.0", "255.0.0.0");
//  Ipv4InterfaceContainer internetIpIfaces = ipv4h.Assign (internetDevices);
  Ipv4InterfaceContainer internetIpv4_ic = ipv4addr_h.Assign (server2pgw_ndc);

  // interface 0 is localhost, 1 is the p2p device
  Ipv4Address serverAddr = internetIpv4_ic.GetAddress (0);

  std::cout << "internetIpv4_ic : " << internetIpv4_ic.Get(0).first->GetAddress(0,0) <<";;"<< internetIpv4_ic.Get(0).second << std::endl; 	/*checking code*/
  std::cout << "internetIpv4_ic : " << internetIpv4_ic.Get(0).first->GetAddress(1,0) << std::endl; 	/*checking code*/
  std::cout << "internetIpv4_ic : " << internetIpv4_ic.Get(1).first->GetAddress(1,0) <<";;"<< internetIpv4_ic.Get(1).second << std::endl; 	/*checking code*/
//  std::cout << "internetIpv4_ic :\t\t" << internetIpv4_ic.Get(0).first->GetAddress(2,0) << std::endl; 	/*checking code*/
  std::cout << "PGW : " << internetIpv4_ic.GetAddress (1) << std::endl; 	/*checking code*/
  std::cout << "PGW(0,0) : " << pgw->GetObject<Ipv4>()->GetAddress(0,0) << std::endl; 	/*checking code*/
  std::cout << "PGW(1,0) : " << pgw->GetObject<Ipv4>()->GetAddress(1,0) << std::endl; 	/*checking code*/
  std::cout << "PGW(2,0) : " << pgw->GetObject<Ipv4>()->GetAddress(2,0) << std::endl; 	/*checking code*/
//  std::cout << "PGW :\t\t" << pgw->GetObject<Ipv4>()->GetAddress(1,1) << std::endl; 	/*checking code*/
  std::cout << "server addr: " << serverAddr << std::endl; 						/*checking code*/
//  std::cout << "server :\t" << internetIpv4_ic.GetAddress (1) << std::endl; 	/*checking code*/
  std::cout << "server(0,0) : " << server->GetObject<Ipv4>()->GetAddress(0,0) << std::endl; 	/*checking code*/
  std::cout << "server(1,0) : " << server->GetObject<Ipv4>()->GetAddress(1,0) << std::endl; 	/*checking code*/
  std::cout << "server'if-1 Naddress : " << server->GetObject<Ipv4>()->GetNAddresses(1) << std::endl; 	/*checking code*/
  std::cout << "server' Nif : " << server->GetObject<Ipv4>()->GetNInterfaces() << std::endl; 	/*checking code*/
//  std::cout << "server :\t" << serverAddr << std::endl; /*checking code*/


  Ipv4StaticRoutingHelper staticRouting_h;
  Ptr<Ipv4StaticRouting> staticRouting = staticRouting_h.GetStaticRouting (server->GetObject<Ipv4> ());
  staticRouting->AddNetworkRouteTo (Ipv4Address ("7.0.0.0"), Ipv4Mask ("255.0.0.0"), 1);


  Ptr<Node> enbNode = CreateObject<Node>();
  Ptr<Node> ueNode = CreateObject<Node>();

  // Install Mobility Model
  Ptr<ListPositionAllocator> positionAlloc = CreateObject<ListPositionAllocator> ();
  positionAlloc->Add (Vector(distance * 0, 0, 0));
//  positionAlloc->Add (Vector(distance * 1, 0, 0));
  positionAlloc->Add (Vector(distance * 0, 0, 0));

  MobilityHelper mobility_h;
  mobility_h.SetMobilityModel("ns3::ConstantPositionMobilityModel");
  mobility_h.SetPositionAllocator(positionAlloc);
  mobility_h.Install(enbNode);
  mobility_h.Install(ueNode);


//  positionAlloc->Add(Vector(0,0,0));


//  std::cout << positionAlloc->GetNext() << std::endl;
//  std::cout << positionAlloc->GetNext() << std::endl;
//  std::cout << positionAlloc->GetNext() << std::endl;
//  std::cout << positionAlloc->GetNext() << std::endl;
//  std::cout << positionAlloc->GetNext() << std::endl;
//  std::cout << positionAlloc->GetNext() << std::endl;
//  std::cout << positionAlloc->GetNext() << std::endl;
//  std::cout << positionAlloc->GetNext() << std::endl;
//  std::cout << positionAlloc->GetNext() << std::endl;
//  std::cout << positionAlloc->GetNext() << std::endl;
//  std::cout << positionAlloc->GetNext() << std::endl;


//  std::cout << mobility.GetDistanceSquaredBetween( enbNodes.Get(0), enbNodes.Get(1) ) << std::endl;
//  std::cout << mobility.GetDistanceSquaredBetween( ueNodes.Get(0), ueNodes.Get(1) ) << std::endl;
//  std::cout << mobility.GetDistanceSquaredBetween( enbNodes.Get(0), ueNodes.Get(0) ) << std::endl;
//  std::cout << mobility.GetDistanceSquaredBetween( enbNodes.Get(1), ueNodes.Get(1) ) << std::endl;

  std::cout << "distance between node and eNB" << mobility_h.GetDistanceSquaredBetween( enbNode, ueNode) << std::endl;

//  std::cout << positionAlloc->GetObject<Vector>() << std::endl;

  // Install LTE Devices to the nodes
  NetDeviceContainer enbLte_ndc = lte_h->InstallEnbDevice (enbNode);
  NetDeviceContainer ueLte_ndc = lte_h->InstallUeDevice (ueNode);

  // Install the IP stack on the UEs
  internetStack_h.Install (ueNode);
  Ipv4InterfaceContainer ueIp_if;
  ueIp_if = epc_h->AssignUeIpv4Address ( ueLte_ndc );



  std::cout << "UE0 : " << ueIp_if.GetAddress(0) << std::endl ; /*checking code*/
  std::cout << "UE0 : " << ueNode->GetObject<Ipv4>()->GetAddress(1,0) << std::endl ; /*checking code*/
  std::cout << "server mtu: " << server->GetObject<Ipv4>()->GetMtu(1) << std::endl ; /*checking code*/
//  std::cout << "UE1 : \t\t" << ueIp_if.GetAddress(1) << std::endl ; /*checking code*/


//  ueIpIface = epcHelper->AssignUeIpv4Address ( ueLteDevs);
  // Assign IP address to UEs, and install applications

  std::cout << "UE's default-GW : " << epc_h->GetUeDefaultGatewayAddress () << std::endl ; /*checking code*/


//  Ptr<Node> ueNode = ueNodes.Get (u);
  // Set the default gateway for the UE
  Ptr<Ipv4StaticRouting> ueStaticRouting = staticRouting_h.GetStaticRouting (ueNode->GetObject<Ipv4> ());
  ueStaticRouting->SetDefaultRoute (epc_h->GetUeDefaultGatewayAddress (), 1);



//      std::cout << ueNode->GetObject<Ipv4>()->GetAddress(1,0) << std::endl ;
//      std::cout << ueStaticRouting->GetDefaultRoute() << std::endl ;
//      std::cout << ueStaticRouting->GetNRoutes() << std::endl ;
//      std::cout << ueStaticRouting->GetRoute(0) << std::endl ;
//      std::cout << ueStaticRouting->GetRoute(1) << std::endl ;
//      std::cout << ueStaticRouting->GetRoute(2) << std::endl ;



  /* Attach one UE per eNodeB */

//  lte_h->Attach (ueLte_ndc, enbLte_ndc);
  lte_h->Attach(ueLte_ndc.Get(0),enbLte_ndc.Get(0));
  // side effect: the default EPS bearer will be activated




  // Install and start applications on UEs and remote host
  uint16_t dlPort = 4380;
  uint16_t ulPort = 4381;

//  uint16_t otherPort = 4382;
  ApplicationContainer pump_ac;
  ApplicationContainer sink_ac;

//  PacketSinkHelper dlPacketSink_h ("ns3::UdpSocketFactory", InetSocketAddress (Ipv4Address::GetAny (), dlPort));
//  PacketSinkHelper dlPacketSink_h ("ns3::TcpSocketFactory", InetSocketAddress (dlPort) );
//  PacketSinkHelper ulPacketSink_h ("ns3::TcpSocketFactory", InetSocketAddress (ulPort) );

  PacketSinkHelper ulPacketSink_h ("ns3::TcpSocketFactory", InetSocketAddress (Ipv4Address::GetAny (), ulPort));
  PacketSinkHelper dlPacketSink_h ("ns3::TcpSocketFactory", InetSocketAddress (Ipv4Address::GetAny (), dlPort));


//  PacketSinkHelper packetSink_h ("ns3::UdpSocketFactory", InetSocketAddress (Ipv4Address::GetAny (), otherPort));

//  std::cout << "InetSocketAddress (Ipv4Address::GetAny (), dlPort):  " << InetSocketAddress (Ipv4Address::GetAny (), dlPort) << std::endl; 	/*checking code*/

  sink_ac.Add (dlPacketSink_h.Install (ueNode));
  sink_ac.Add (ulPacketSink_h.Install (server));

//  BulkSendHelper bulkSend_h("ns3::TcpSocketFactory", InetSocketAddress(ueIp_if.GetAddress (0),dlPort) );
  BulkSendHelper bulkSend_h("ns3::TcpSocketFactory", InetSocketAddress(ueIp_if.GetAddress (0),dlPort) );


//  server_ac.Add (packetSink_h.Install (ueNode));

//  UdpClientHelper udpServer_h (ueIp_if.GetAddress (0), dlPort);
//  udpServer_h.SetAttribute ("Interval", TimeValue (MilliSeconds(interPacketInterval)));
//  udpServer_h.SetAttribute ("MaxPackets", UintegerValue(1000000));
//  udpServer_h.SetAttribute ("PacketSize", UintegerValue(1400));   /*increase packet size up to 1400*/
//
//  UdpClientHelper udpClient_h (serverAddr, ulPort);
//  udpClient_h.SetAttribute ("Interval", TimeValue (MilliSeconds(interPacketInterval)));
//  udpClient_h.SetAttribute ("MaxPackets", UintegerValue(1000000));
  bulkSend_h.SetAttribute("MaxBytes" , UintegerValue(0) ); // 0 means unlimited,,
  bulkSend_h.SetAttribute("SendSize" , UintegerValue(1000)); // 1000 Bytes

  pump_ac.Add( bulkSend_h.Install(server) );


//  pump_ac.Add( bulkSend_h.Install(ueNode) );
//  UdpClientHelper client_h (ueIp_if.GetAddress (0), otherPort);
//  client_h.SetAttribute ("Interval", TimeValue (MilliSeconds(interPacketInterval)));
//  client_h.SetAttribute ("MaxPackets", UintegerValue(1000000));

//  pump_ac.Add (udpServer_h.Install (server));
//  pump_ac.Add (udpClient_h.Install (ueNode));
//  client_ac.Add (client_h.Install (ueNode));



  std::cout << "eNB(0,0) : " << enbNode->GetObject<Ipv4>()->GetAddress(0,0) << std::endl; 	/*checking code*/
  std::cout << "eNB(1,0) : " << enbNode->GetObject<Ipv4>()->GetAddress(1,0) << std::endl; 	/*checking code*/
//  std::cout << "eNB(2,0) :\t\t" << enbNode->GetObject<Ipv4>()->GetAddress(2,0) << std::endl; 	/*checking code*/
//  std::cout << "eNB'if-2 Naddress :\t" << enbNode->GetObject<Ipv4>()->GetNAddresses(2) << std::endl; 	/*checking code*/
  std::cout << "eNB' Nif : " << enbNode->GetObject<Ipv4>()->GetNInterfaces() << std::endl; 	/*checking code*/


//  std::cout << ueNodes.Get(0)->GetObject<InetSocketAddress>()->GetIpv4() << std::endl ;
//  std::cout << Ipv4Address::ConvertFrom( ueNodes.Get(0)->GetDevice(0)->GetAddress() )   << std::endl ;
//  Ipv4Address myaddress( ueNodes.Get(0)->GetDevice(0)->GetAddress() );
//  std::cout <<  myaddress.Get()  << std::endl ;
//  InetSocketAddress myaddress =
//  std::cout <<  ueNodes.Get(0)->GetDevice(0)->GetAddress().R << std::endl ;


/*  Ipv4InterfaceContainer ipv4if_1 = ipv4h.Assign( NetDeviceContainer(ueNodes.Get(0)->GetDevice(0)));
  std::cout <<  ipv4if_1.GetAddress(0)  << std::endl ;
  Ipv4InterfaceContainer ipv4if_2 = ipv4h.Assign( NetDeviceContainer(ueNodes.Get(1)->GetDevice(0)));
  std::cout <<  ipv4if_2.GetAddress(0)  << std::endl ;
  Ipv4InterfaceContainer ipv4if_3 = ipv4h.Assign( NetDeviceContainer(enbNodes.Get(0)->GetDevice(0)));
  std::cout <<  ipv4if_3.GetAddress(0)  << std::endl ;
  Ipv4InterfaceContainer ipv4if_4 = ipv4h.Assign( NetDeviceContainer(enbNodes.Get(1)->GetDevice(0)));
  std::cout <<  ipv4if_4.GetAddress(0)  << std::endl ;*/

  sink_ac.Start (Seconds (0.0));
  pump_ac.Start (Seconds (0.0));

  sink_ac.Stop (Seconds (simTime));
  pump_ac.Stop (Seconds (simTime));


  lte_h->EnableTraces ();
  // Uncomment to enable PCAP tracing
  //p2ph.EnablePcapAll("lena-epc-first");

  std::cout << "server node id : " << server->GetId() << std::endl; /*checking code*/
  std::cout << "pgw node id : " <<pgw->GetId() << std::endl; /*checking code*/
  std::cout << "enb node id : " <<enbNode->GetId() << std::endl; /*checking code*/
  std::cout << "ue node id : " <<ueNode->GetId() << std::endl; /*checking code*/

//  p2p_h->ipv4addr_h->
  p2p_h.EnablePcapAll("MHTCP-P2P");
//  p2p_h.EnablePcap("MKTCP", ns3::NodeContainer(enbNode));

//  lte_h.EnablePcapAll("MHTCP-LTE");
//  epc_h.EnablePcapAll("MHTCP-EPC");
//  p2p_h.enablep

  AsciiTraceHelper asciiTrace_h;
  p2p_h.EnableAsciiAll( asciiTrace_h.CreateFileStream("MHTCP-P2P.tr"));


  Simulator::Stop(Seconds(simTime));
  Simulator::Run();

  /*GtkConfigStore config;
  config.ConfigureAttributes();*/

  Simulator::Destroy();
  return 0;

}

