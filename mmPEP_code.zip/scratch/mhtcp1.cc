/*
 * Author: Minho Kim (mhkim@ramo.yonsei.ac.kr)
 * Yonsei Univ. in Seoul, South-Korea.
 * This is to simulate and analysis for wireless-TCP
 */


#include "ns3/lte-helper.h"
#include "ns3/epc-helper.h"
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/ipv4-global-routing-helper.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/lte-module.h"
#include "ns3/applications-module.h"
#include "ns3/point-to-point-helper.h"
#include "ns3/config-store.h"
//#include "ns3/gtk-config-store.h"

/*
 *
 *     Server ----------[node1]---------------[node2]---------------UE
 *     1.0.0.1       1.0.0.2       2.0.0.1      2.0.0.2     2.0.0.3      2.0.0.4
 *
 *
 *
 * */


using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("mhtcp1");



 /*MyTcp application on server*/

class MyTcp : public Application
{
public:
	MyTcp();
	virtual ~MyTcp();

	void Setup (Ptr<Socket> socket, Address address, uint32_t packetSize, uint32_t nPackets, DataRate dataRate);

private:
	virtual void StartApplication(void);
	virtual void StopApplication(void);
	void ScheduledTx(void);
	void SendPacket(void);

	Ptr<Socket> m_socket;
	Address m_peer;
	uint32_t m_packetSize;
	uint32_t m_nPackets;
	DataRate m_dataRate;
	EventId m_sendEvent;
	bool m_running;
	uint32_t m_packetsSent;

};

MyTcp::MyTcp()
	: m_socket(0),
	  m_peer(),
	  m_packetSize(0),
	  m_nPackets(0),
	  m_dataRate(0),
	  m_sendEvent(),
	  m_running(false),
	  m_packetsSent(0)
{

}

MyTcp::~MyTcp()
{
	m_socket=0;
}

void MyTcp::Setup(Ptr<Socket> socket, Address address, uint32_t packetSize, uint32_t nPackets, DataRate dataRate)
{
	m_socket = socket;
	m_peer = address;
	m_packetSize = packetSize;
	m_nPackets = nPackets;
	m_dataRate = dataRate;
}


void MyTcp::StartApplication(void)
{
	m_running = true;
	m_packetsSent = 0;
	m_socket->Bind();
	m_socket->Connect(m_peer);
	SendPacket();
}

void MyTcp::StopApplication(void)
{
	m_running = false;

	if(m_sendEvent.IsRunning())
	{
		Simulator::Cancel(m_sendEvent);
	}

	if(m_socket)
	{
		m_socket->Close();
	}
}


void MyTcp::SendPacket(void)
{
	Ptr<Packet> packet = Create<Packet> (m_packetSize);
	m_socket->Send(packet);

	if( ++m_packetsSent < m_nPackets)
	{
		ScheduledTx();
	}
}


void MyTcp::ScheduledTx(void)
{
	if( m_running)
	{
		Time tNext( Seconds(m_packetSize * 8 / static_cast<double> (m_dataRate.GetBitRate() ) ));
		m_sendEvent = Simulator::Schedule( tNext , &MyTcp::SendPacket , this );
	}

}

static void CwndChange (Ptr<OutputStreamWrapper> stream, uint32_t oldCwnd, uint32_t newCwnd )
{
	*stream->GetStream() << Simulator::Now().GetSeconds() << "old:\t" << oldCwnd << "new:\t" << newCwnd << std::endl ;
}






void SendEarlyAck( Ptr<Packet> dataPacket, Ptr<Ipv4> ipv4, uint32_t interface
			,uint16_t preAckWin , Ipv4Header preIpv4Heaer, TcpHeader preTcpHeader, uint8_t preTcpFlag)
{
	static bool disableEA = false;
	if (disableEA)
		return;

	Ipv4Header ipv4Header; //original header of data
	Ipv4Header ipv4HeaderEA; // Early Ack header corresponding to received data
	static SequenceNumber32 earlyAckedSeq(0);


//	uint32_t ipv4HeaderReading =
	dataPacket->PeekHeader(ipv4Header);
	ipv4HeaderEA = preIpv4Heaer;

//	std::cout << "test earlyAckedSeq-------------" <<  earlyAckedSeq << std::endl;

	Ipv4Address destination = ipv4Header.GetDestination();
	Ipv4Address source = ipv4Header.GetSource();
	uint16_t tcpTotalSize = ipv4Header.GetPayloadSize() ; //tcplayload - ipheadersize

//	std::cout << "Data packet's source addr: " <<  source << std::endl;
//	std::cout << "Data packet's destination addr: " <<  destination << std::endl;

	ipv4HeaderEA.SetDestination(source);// exchange ipv4 addresses
	ipv4HeaderEA.SetSource(destination);
	ipv4HeaderEA.EnableChecksum();

	Ptr<Ipv4Route> ipv4RouteEA = Create<Ipv4Route>();
	ipv4RouteEA->SetDestination(source);
	ipv4RouteEA->SetGateway(source);
	ipv4RouteEA->SetOutputDevice( ipv4->GetNetDevice(interface)); // send back to the interface where it comes from
	ipv4RouteEA->SetSource(destination);

	dataPacket->RemoveHeader(ipv4Header); //delete duplicated ipv4 header

	TcpHeader tcpHeader;
	TcpHeader tcpHeaderEA;
//	uint32_t tcpHeaderReading =
	dataPacket->PeekHeader(tcpHeader);
	tcpHeaderEA = preTcpHeader;

	if (tcpHeader.GetFlags() == 2)// if it's SYN,,
	{
		return;
	}

	SequenceNumber32 dataSeqNum = tcpHeader.GetSequenceNumber();
//	SequenceNumber32 dataAckNum = tcpHeader.GetAckNumber();
	uint16_t dataSrcPort = tcpHeader.GetSourcePort();
	uint16_t dataDstPort = tcpHeader.GetDestinationPort();
	uint32_t tcpHeaderSize = tcpHeader.GetSerializedSize();
	uint16_t tcpdatasize = tcpTotalSize - tcpHeaderSize; //for calculate ack num for data

	tcpHeaderEA.SetAckNumber(dataSeqNum + tcpdatasize);
	tcpHeaderEA.SetDestinationPort(dataSrcPort);
	tcpHeaderEA.SetSourcePort(dataDstPort);
	tcpHeaderEA.EnableChecksums();

	Ptr<Packet> newpacket = Create<Packet>(0);
	newpacket->AddHeader(tcpHeaderEA);
//	newpacket->AddHeader(ipv4HeaderEA);

//	std::cout << "Tcp-data's reading bytes : " <<  tcpHeaderReading << std::endl;
//	std::cout << "Tcp-data's seq num : " <<  dataSeqNum<< std::endl;
//	std::cout << "Tcp-data's ack num : " <<  dataAckNum<< std::endl;
//	std::cout << "Tcp-data's src-port : " <<  dataSrcPort << std::endl;
//	std::cout << "Tcp-data's dst-port : " <<  dataDstPort << std::endl;
//	std::cout << "Tcp-data's size : " <<  tcpHeader.GetSerializedSize() << std::endl;
//	std::cout << "Ip header's size : " <<  ipv4HeaderReading << std::endl;


	if( interface == 1)
	{
		// for packets from server to ue
		if( preTcpFlag != 18 && earlyAckedSeq!=tcpHeaderEA.GetAckNumber() )
		{
			ipv4->SendWithHeader(newpacket, ipv4HeaderEA, ipv4RouteEA);
			earlyAckedSeq = tcpHeaderEA.GetAckNumber();
			return;
		}


	}
	if( interface == 2)
	{
		// for packets from server to ue
		if( preTcpFlag != 18 && earlyAckedSeq!=tcpHeaderEA.GetAckNumber() )
		{

			earlyAckedSeq = tcpHeaderEA.GetAckNumber();
			ipv4->SetForwarding(2,false);
			return;
		}


	}
}





void RxPacketTrace( Ptr<const Packet> pkt, Ptr<Ipv4> ipv4, uint32_t interface )
{

	static uint16_t preAckWin = 50000;
	static Ipv4Header preIpv4Header;
	static TcpHeader preTcpHeader;
	static uint8_t preTcpFlag;
//	static bool is

//	std::cout << "incoming interface:" << interface << std::endl;

	ipv4->SetForwarding(2,true);
	ipv4->SetForwarding(1,true);

	if( interface == 2) //if it is tcp ack packet
	{

		Ptr<Packet> packet = pkt->Copy();
		packet->PeekHeader(preIpv4Header);
		packet->RemoveHeader(preIpv4Header);
		packet->PeekHeader(preTcpHeader);
		preAckWin = preTcpHeader.GetWindowSize();
		preTcpFlag = preTcpHeader.GetFlags();

//		std::cout << "Pre-AckWindow is..." << preAckWin << std::endl;


		return; // if it is not data TCP,,
	}


//	double rxTime = Simulator::Now().GetSeconds();
//	uint32_t rxByte = pkt->GetSize();
	Ptr<Packet> dataPacket = pkt->Copy();
	// if incoming interface is 1 and forwarding interface should be 2
//	uint8_t outgoingif = interface==1?2:1;

//	std::cout << rxTime << "\t\t" << "Rx byte:" << rxByte << std::endl;

	SendEarlyAck( dataPacket , ipv4, interface , preAckWin, preIpv4Header, preTcpHeader, preTcpFlag);


}






void SpecialEvent(PointToPointHelper& p2p_2_h)
{
	std::cout << "**********************************************************************************************************************" << std::endl;
	//p2p_2_h->SetDeviceAttribute ("DataRate", StringValue("1Mbps") );
	p2p_2_h.SetDeviceAttribute("DataRate", StringValue("1kbps") );

	return;
}









/**********************  Main function  ***********************/









int
main (int argc, char *argv[])
{
  /*Simulation parameter*/
  double simTime = 5.0 ;
  std::string tcpProtocol = "TcpNewReno";

  std::string bandwidth = "100Mbps";
  std::string bandwidthBsUe = "1Mbps";
  int mtu = 1500;
  uint32_t packetSize = 1446;
  uint32_t segmentSize = 1446;
  uint32_t nPackets = 100000;
  std::string dataRate = "20Mbps";
  std::string delay = "5ms";
  std::string delayBsUe = "20ms";


  double errorRate = 0.0;
  int basic_queueSize = 100; // num of packets
  int BS_queueSize = 2;



  if( tcpProtocol.compare("TcpNewReno") == 0)
  {
	  Config::SetDefault("ns3::TcpL4Protocol::SocketType", TypeIdValue( TcpNewReno::GetTypeId() ) );

  }
  else
  {
	  printf("TCP type error\n");
	  exit(1);
  }

  /*basic queue size*/
  Config::SetDefault("ns3::DropTailQueue::MaxPackets", UintegerValue( uint32_t(basic_queueSize)));


  /*Command line arguments*/
  CommandLine cmd;
  cmd.Parse(argc, argv);


  /*Create nodes*/
  Ptr<Node> server = CreateObject<Node>();
  Ptr<Node> node1 = CreateObject<Node>();
  Ptr<Node> node2 = CreateObject<Node>();
  Ptr<Node> ue = CreateObject<Node>();

  /*install internet stack*/
  InternetStackHelper internetStack_h;
  internetStack_h.Install (server);
  internetStack_h.Install (node1);
  internetStack_h.Install (node2);
  internetStack_h.Install (ue);



  /*Create the Internet attribute by using p2p-helper*/
  PointToPointHelper p2p_1_h;
  p2p_1_h.SetDeviceAttribute ("DataRate", StringValue(bandwidth) );
  p2p_1_h.SetDeviceAttribute ("Mtu", UintegerValue (mtu));
  p2p_1_h.SetChannelAttribute ("Delay", StringValue(delay) );

  NetDeviceContainer server_node1_ndc = p2p_1_h.Install (server,node1);
  NetDeviceContainer node1_node2_ndc = p2p_1_h.Install (node1,node2);


//  PointToPointHelper p2p_2_h;
//  p2p_2_h.SetDeviceAttribute ("DataRate", StringValue(bandwidthBsUe) );
//  p2p_2_h.SetDeviceAttribute ("Mtu", UintegerValue (mtu));
//  p2p_2_h.SetChannelAttribute ("Delay", StringValue(delayBsUe) );
//  p2p_2_h.SetQueue("ns3::DropTailQueue","MaxPackets", UintegerValue(BS_queueSize));



  PointToPointHelper p2p_2_h;
  p2p_2_h.SetDeviceAttribute ("DataRate", StringValue(bandwidthBsUe) );
  p2p_2_h.SetDeviceAttribute ("Mtu", UintegerValue (mtu));
  p2p_2_h.SetChannelAttribute ("Delay", StringValue(delayBsUe) );
  p2p_2_h.SetQueue("ns3::DropTailQueue","MaxPackets", UintegerValue(BS_queueSize));



  NetDeviceContainer node2_ue_ndc = p2p_2_h.Install (node2,ue);

  /*Create Error model on a receiver*/
  Ptr<RateErrorModel> em = CreateObject<RateErrorModel>();
  em->SetAttribute("ErrorRate", DoubleValue(errorRate));
  node2_ue_ndc.Get(1)->SetAttribute("ReceiveErrorModel", PointerValue(em));


  Ipv4AddressHelper ipv4addr1_h;
  ipv4addr1_h.SetBase ("1.0.0.0", "255.0.0.0");
  Ipv4InterfaceContainer internetIpv4_ic = ipv4addr1_h.Assign (server_node1_ndc);

  Ipv4AddressHelper ipv4addr2_h;
  ipv4addr2_h.SetBase ("2.0.0.0", "255.0.0.0");
  Ipv4InterfaceContainer localIpv4_1_ic = ipv4addr2_h.Assign (node1_node2_ndc);
  Ipv4InterfaceContainer localIpv4_2_ic = ipv4addr2_h.Assign (node2_ue_ndc);

  std::cout << "link0-0 : " << internetIpv4_ic.GetAddress(0) << std::endl; 	/*checking code*/
  std::cout << "link0-1 : " << internetIpv4_ic.GetAddress(1) << std::endl; 	/*checking code*/
  std::cout << "link1-0 : " << localIpv4_1_ic.GetAddress(0) << std::endl; 	/*checking code*/
  std::cout << "link1-1 : " << localIpv4_1_ic.GetAddress(1) << std::endl; 	/*checking code*/
  std::cout << "link2-0 : " << localIpv4_2_ic.GetAddress(0) << std::endl; 	/*checking code*/
  std::cout << "link2-1 : " << localIpv4_2_ic.GetAddress(1) << std::endl; 	/*checking code*/

  Ipv4StaticRoutingHelper staticRouting_h;
  Ptr<Ipv4StaticRouting> serverStaticRouting = staticRouting_h.GetStaticRouting (server->GetObject<Ipv4> ());
  serverStaticRouting->AddNetworkRouteTo (Ipv4Address ("2.0.0.0"), Ipv4Mask ("255.0.0.0"), 1);

  Ptr<Ipv4StaticRouting> ueStaticRouting = staticRouting_h.GetStaticRouting (ue->GetObject<Ipv4> ());
  ueStaticRouting->AddNetworkRouteTo (node1->GetObject<Ipv4>()->GetAddress(1,0).GetLocal(),
		                               node1->GetObject<Ipv4>()->GetAddress(1,0).GetMask(),  1);
//  std::cout << "node1's info : " << node1->GetObject<Ipv4>()->GetAddress(1,0) << std::endl;
//  std::cout << "node1's info : " << Ipv4Address ("2.0.0.0") << std::endl;

  /* Print out routing table*/
  std::cout << "server's route table : " << std::endl;
  for (uint32_t i=0 ; i< staticRouting_h.GetStaticRouting(server->GetObject<Ipv4>())->GetNRoutes() ; i++)
  {
	  std::cout << "route table " << i << ":" << staticRouting_h.GetStaticRouting(server->GetObject<Ipv4>())->GetRoute(i) <<std::endl;
  }

  std::cout << "ue's route table : " << std::endl;
  for (uint32_t i=0 ; i< staticRouting_h.GetStaticRouting(ue->GetObject<Ipv4>())->GetNRoutes() ; i++)
  {
	  std::cout << "route table " << i << ":" << staticRouting_h.GetStaticRouting(ue->GetObject<Ipv4>())->GetRoute(i) <<std::endl;
  }

  std::cout << "node1 if 1 : " << node1->GetObject<Ipv4>()->GetAddress(1,0) << std::endl ;
  std::cout << "node1 if 2 : " << node1->GetObject<Ipv4>()->GetAddress(2,0) << std::endl ;
  std::cout << "node2 if 1 : " << node2->GetObject<Ipv4L3Protocol>()->GetAddress(1,0) << std::endl ;



  Ipv4GlobalRoutingHelper::PopulateRoutingTables ();

//  Ptr<Ipv4L3Protocol> node2Ipv4 = node2->GetObject<Ipv4L3Protocol>();



  /* Install and start applications on UEs and remote host*/
  uint16_t dlPort = 4380;
//  uint16_t ulPort = 4381;

  Address ueSinkAddress ( InetSocketAddress( localIpv4_2_ic.GetAddress(1) , dlPort ) );
  PacketSinkHelper packetSink_h( "ns3::TcpSocketFactory", InetSocketAddress(Ipv4Address::GetAny(), dlPort ));


  /*Sink Application on UE*/
  ApplicationContainer sink_ac = packetSink_h.Install(ue);
  sink_ac.Start( Seconds(0.));
  sink_ac.Stop( Seconds(simTime) );


  /*Pump Application on Server*/
  Ptr<MyTcp> pump_ac = CreateObject<MyTcp>();
  Ptr<Socket> tcpSocket = Socket::CreateSocket(server, TcpSocketFactory::GetTypeId());

  tcpSocket->SetAttribute("SegmentSize", UintegerValue(segmentSize));

  pump_ac->Setup( tcpSocket, ueSinkAddress, packetSize, nPackets, DataRate(dataRate) );


  server->AddApplication(pump_ac);
  pump_ac->SetStartTime( Seconds(0.5));
  pump_ac->SetStopTime( Seconds(simTime) );

//  std::cout << node2->GetId() << std::endl;

  AsciiTraceHelper asciiTrace_h;
  Ptr<OutputStreamWrapper> outStream = asciiTrace_h.CreateFileStream("MH-TCP_cwnd");
  tcpSocket->TraceConnectWithoutContext("CongestionWindow" , MakeBoundCallback(&CwndChange, outStream));

  p2p_1_h.EnablePcapAll("MHTCP-wiredtest-");

  Config::ConnectWithoutContext("/NodeList/2/$ns3::Ipv4L3Protocol/Rx", MakeCallback(&RxPacketTrace));



  Simulator::Schedule(Seconds(3), &SpecialEvent, p2p_2_h);
  Simulator::Stop(Seconds(simTime));
  Simulator::Run();
  Simulator::Destroy();
  return 0;

}

